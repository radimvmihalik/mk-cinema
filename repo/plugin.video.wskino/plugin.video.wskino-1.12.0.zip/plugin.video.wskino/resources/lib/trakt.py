# -*- coding: utf-8 -*-
"""Trakt.tv client: device sign-in, the user's lists and progress, watched marks and scrobbling.

Only the app's public Client ID is needed: since October 2026 Trakt issues no client secret and the
device flow works without one. Access tokens last 7 days; refresh tokens are single-use, so a
refresh is done under a lock (the plugin and the scrobbling service may run at the same time).
"""
import json
import os
import time

import requests

API_URL = "https://api.trakt.tv"
REDIRECT_URI = "urn:ietf:wg:oauth:2.0:oob"
REFRESH_BEFORE = 24 * 3600   # refresh when less than a day of the 7 is left
ACTIVITY_TTL = 5 * 60        # how often to ask whether anything changed on Trakt
TOKEN_FILE = "trakt"


class TraktError(Exception):
    def __init__(self, message, status=None):
        Exception.__init__(self, message)
        self.status = status


class Trakt(object):
    def __init__(self, client_id, storage, user_agent="MK Cinema", timeout=20):
        self.client_id = (client_id or "").strip()
        self.storage = storage
        self.user_agent = user_agent
        self.timeout = timeout

    # ------------------------------------------------------------------ account
    @property
    def configured(self):
        return bool(self.client_id)

    @property
    def token(self):
        return self.storage.load(TOKEN_FILE, {}) or {}

    @property
    def connected(self):
        return bool(self.configured and self.token.get("access_token"))

    @property
    def username(self):
        return self.token.get("username", "")

    def device_code(self):
        return self._call("POST", "/oauth/device/code", {"client_id": self.client_id}, auth=False)

    def poll_device_token(self, device_code):
        """(status, data): 200 signed in; 400 still waiting; 404/409/410/418 failed; 429 poll slower."""
        resp = self._raw("POST", "/oauth/device/token", {"code": device_code, "client_id": self.client_id}, auth=False)
        if resp.status_code == 200:
            data = resp.json()
            self._save_token(data)
            try:
                settings = self.get("/users/settings")
                self._update_token(username=settings.get("user", {}).get("username", ""))
            except TraktError:
                pass
            return 200, data
        return resp.status_code, None

    def disconnect(self):
        token = self.token.get("access_token")
        if token:
            try:
                self._raw("POST", "/oauth/revoke", {"token": token, "client_id": self.client_id}, auth=False)
            except requests.RequestException:
                pass
        self.storage.save(TOKEN_FILE, {})
        self.forget()

    def _save_token(self, data):
        old = self.token
        self.storage.save(TOKEN_FILE, {
            "access_token": data["access_token"], "refresh_token": data.get("refresh_token", ""),
            "expires_at": int(data.get("created_at") or time.time()) + int(data.get("expires_in") or 7 * 86400),
            "username": old.get("username", ""),
        })

    def _update_token(self, **values):
        token = self.token
        token.update(values)
        self.storage.save(TOKEN_FILE, token)

    def _refresh(self):
        """New tokens; another process may have refreshed meanwhile, then its tokens are used."""
        lock = os.path.join(self.storage.folder, "trakt.lock")
        for _ in range(50):  # wait up to 10 s for another refresh
            try:
                fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except OSError:
                if time.time() - os.path.getmtime(lock) > 30:  # left over from a crash
                    os.remove(lock)
                time.sleep(0.2)
        else:
            return
        try:
            os.close(fd)
            token = self.token
            if token.get("expires_at", 0) - time.time() > REFRESH_BEFORE:
                return  # someone else just did it
            resp = self._raw("POST", "/oauth/token", {
                "refresh_token": token.get("refresh_token", ""), "client_id": self.client_id,
                "redirect_uri": REDIRECT_URI, "grant_type": "refresh_token"}, auth=False)
            if resp.status_code == 200:
                self._save_token(resp.json())
            elif resp.status_code in (400, 401):
                self.storage.save(TOKEN_FILE, {})
                raise TraktError("Přihlášení k Traktu vypršelo, připoj účet znovu v nastavení.", resp.status_code)
        finally:
            try:
                os.remove(lock)
            except OSError:
                pass

    # ------------------------------------------------------------------ HTTP
    def _headers(self, auth):
        headers = {"Content-Type": "application/json", "trakt-api-version": "2", "trakt-api-key": self.client_id,
                   "User-Agent": self.user_agent}
        if auth:
            headers["Authorization"] = "Bearer %s" % self.token.get("access_token", "")
        return headers

    def _raw(self, method, path, body=None, params=None, auth=True):
        return requests.request(method, API_URL + path, headers=self._headers(auth), params=params,
                                data=json.dumps(body) if body is not None else None, timeout=self.timeout)

    def _call(self, method, path, body=None, params=None, auth=True, full=False):
        if not self.configured:
            raise TraktError("Propojení s Traktem v této verzi doplňku není nastavené.")
        if auth:
            if not self.connected:
                raise TraktError("Nejdřív připoj účet Trakt (v menu Trakt nebo v nastavení).")
            if self.token.get("expires_at", 0) - time.time() < REFRESH_BEFORE:
                self._refresh()
        try:
            resp = self._raw(method, path, body, params, auth)
            if resp.status_code == 401 and auth:
                self._update_token(expires_at=0)
                self._refresh()
                resp = self._raw(method, path, body, params, auth)
        except requests.RequestException as exc:
            raise TraktError("Trakt neodpovídá (%s)." % exc.__class__.__name__)
        if resp.status_code == 401:
            raise TraktError("Přihlášení k Traktu vypršelo, připoj účet znovu v nastavení.", 401)
        if resp.status_code == 420:
            raise TraktError("Bezplatný účet Trakt narazil na limit (např. počet položek ve watchlistu).", 420)
        if resp.status_code == 429:
            raise TraktError("Trakt teď odmítá další požadavky, zkus to za chvíli.", 429)
        if resp.status_code >= 400:
            raise TraktError("Trakt odpověděl chybou %d." % resp.status_code, resp.status_code)
        data = None if resp.status_code == 204 or not resp.content else resp.json()
        return (data, resp.headers) if full else data

    def get(self, path, **params):
        return self._call("GET", path, params=params or None)

    def get_all(self, path, limit=250, max_pages=40, **params):
        """Every page of a paginated list (Trakt pages by 100 unless asked, 250 at most)."""
        items, page = [], 1
        while page <= max_pages:
            data, headers = self._call("GET", path, params=dict(params, page=page, limit=limit), full=True)
            items += data or []
            if page >= int(headers.get("x-pagination-page-count") or headers.get("X-Pagination-Page-Count") or 1):
                break
            page += 1
        return items

    def post(self, path, body):
        return self._call("POST", path, body)

    # ------------------------------------------------------------------ cached state
    def activities(self):
        """Latest change times on Trakt, asked at most every ACTIVITY_TTL."""
        data = self.storage.cache_get("trakt:activities", ACTIVITY_TTL)
        if data is None:
            data = self.get("/sync/last_activities") or {}
            self.storage.cache_set("trakt:activities", data)
        return data

    def forget(self):
        """After a change made here: ask Trakt for fresh state on the next listing."""
        self.storage.cache_set("trakt:activities", None)

    def _by_activity(self, name, stamps, build):
        key = "trakt:%s:%s:%s" % (self.username, name, "|".join(stamps))
        data = self.storage.cache_get(key, 30 * 86400)
        if data is None:
            data = build()
            self.storage.cache_set(key, data)
        return data

    def watched_movies(self):
        """TMDB ids of the watched films."""
        stamp = self.activities().get("movies", {}).get("watched_at", "")

        def build():
            return [m for m in (i.get("movie", {}).get("ids", {}).get("tmdb") for i in self.get_all("/sync/watched/movies")) if m]
        return self._by_activity("watched_movies", [stamp], build)

    def trakt_id(self, kind, tmdb_id):
        """Trakt id of a show or movie known by its TMDB id (they never change, so cached for long)."""
        key = "trakt:id:%s:%s" % (kind, tmdb_id)
        found = self.storage.cache_get(key, 90 * 86400)
        if found is None:
            results = self.get("/search/tmdb/%s" % tmdb_id, type=kind) or []
            found = next((r[kind]["ids"]["trakt"] for r in results if r.get("type") == kind and r.get(kind)), 0)
            self.storage.cache_set(key, found)
        return found

    def watched_episodes(self, show_tmdb_id):
        """["season:episode", ...] watched in one show (Trakt no longer lists episodes in /sync/watched/shows)."""
        stamp = self.activities().get("episodes", {}).get("watched_at", "")

        def build():
            trakt_id = self.trakt_id("show", show_tmdb_id)
            if not trakt_id:
                return []
            progress = self.get("/shows/%s/progress/watched" % trakt_id, specials="true", hidden="false") or {}
            return ["%d:%d" % (s["number"], e["number"]) for s in progress.get("seasons", [])
                    for e in s.get("episodes", []) if e.get("completed")]
        return self._by_activity("show:%s" % show_tmdb_id, [stamp], build)

    def watchlist_ids(self):
        """{"movie": [tmdb ids], "tv": [tmdb ids]} on the watchlist."""
        acts = self.activities()
        stamps = [acts.get("movies", {}).get("watchlisted_at", ""), acts.get("shows", {}).get("watchlisted_at", "")]

        def build():
            return {"movie": [i["movie"]["ids"].get("tmdb") for i in self.watchlist("movies")],
                    "tv": [i["show"]["ids"].get("tmdb") for i in self.watchlist("shows")]}
        return self._by_activity("watchlist", stamps, build)

    # ------------------------------------------------------------------ lists
    def watchlist(self, kind):
        return self.get_all("/sync/watchlist/%s/added/desc" % kind)

    def up_next(self):
        return self.get("/sync/progress/up_next", limit=40) or []

    def playback(self):
        return self.get("/sync/playback") or []

    def history(self, page=1, limit=40):
        return self.get("/sync/history", page=page, limit=limit) or []

    def lists(self):
        return self.get("/users/me/lists") or []

    def list_items(self, list_id):
        return self.get_all("/users/me/lists/%s/items/movie,show" % list_id)

    def recommendations(self, kind):
        return self.get("/recommendations/%s" % kind, limit=40, ignore_collected="true") or []

    # ------------------------------------------------------------------ changes
    @staticmethod
    def body(media, tmdb_id, season=None, episode=None):
        """Sync payload for a film, a series or one episode of a series (all by TMDB id)."""
        if media == "movie":
            return {"movies": [{"ids": {"tmdb": int(tmdb_id)}}]}
        show = {"ids": {"tmdb": int(tmdb_id)}}
        if episode is not None:
            show["seasons"] = [{"number": int(season), "episodes": [{"number": int(episode)}]}]
        return {"shows": [show]}

    def change(self, what, media, tmdb_id, season=None, episode=None):
        """what: watchlist_add, watchlist_remove, watched_add, watched_remove."""
        path = {"watchlist_add": "/sync/watchlist", "watchlist_remove": "/sync/watchlist/remove",
                "watched_add": "/sync/history", "watched_remove": "/sync/history/remove"}[what]
        result = self.post(path, self.body(media, tmdb_id, season, episode))
        self.forget()
        return result

    @staticmethod
    def scrobble_body(play, progress):
        """Scrobble payload for what MK Cinema plays: a film by TMDB id or an episode by show TMDB id + S×E."""
        if play.get("media") == "movie":
            body = {"movie": {"ids": {"tmdb": int(play["id"])}}}
        else:
            body = {"show": {"ids": {"tmdb": int(play["id"])}},
                    "episode": {"season": int(play["season"]), "number": int(play["episode"])}}
        body["progress"] = round(max(0.0, min(100.0, float(progress))), 2)
        return body

    def scrobble(self, action, play, progress):
        """action: start, pause, stop (stop at 80 % or more marks it watched, below saves the position)."""
        result = self.post("/scrobble/%s" % action, self.scrobble_body(play, progress))
        if action != "start":
            self.forget()
        return result
