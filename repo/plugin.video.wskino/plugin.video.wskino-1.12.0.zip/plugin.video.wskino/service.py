# -*- coding: utf-8 -*-
"""Background service: tells Trakt what MK Cinema plays (start, pause, stop with the position).

The plugin leaves what it started in a window property (see PLAYING_PROPERTY in plugin.py);
anything else Kodi plays is ignored. Stopping at 80 % or more marks it watched on Trakt,
earlier it is kept as "Rozkoukané".
"""
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.storage import Storage
from resources.lib.trakt import Trakt, TraktError

PLAYING_PROPERTY = "mkcinema.playing"
HOME = xbmcgui.Window(10000)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[plugin.video.wskino] service: %s" % msg, level)


def client():
    addon = xbmcaddon.Addon()
    bundled = os.path.join(addon.getAddonInfo("path"), "resources", "trakt_client_id.txt")
    client_id = ""
    if os.path.isfile(bundled):
        with open(bundled, encoding="utf-8") as fh:
            client_id = fh.read().strip()
    storage = Storage(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
    return Trakt(client_id or addon.getSetting("trakt_client_id").strip(), storage,
                 "MK Cinema/%s (Kodi)" % addon.getAddonInfo("version"))


class Scrobbler(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.current = None
        self.position = 0.0
        self.total = 0.0

    def progress(self):
        return 100.0 * self.position / self.total if self.total else 0.0

    def update(self):
        try:
            self.position = self.getTime()
            self.total = self.getTotalTime() or self.total
        except RuntimeError:  # nothing is playing any more
            pass

    def send(self, action):
        if not self.current or xbmcaddon.Addon().getSetting("trakt_scrobble") == "false":
            return
        trakt = client()
        if not trakt.connected:
            return
        try:
            trakt.scrobble(action, self.current, self.progress())
            log("scrobble %s %s %.1f %%" % (action, self.current, self.progress()))
        except TraktError as exc:
            log("scrobble %s failed: %s" % (action, exc), xbmc.LOGWARNING)

    def onAVStarted(self):
        self.current, self.position, self.total = None, 0.0, 0.0
        raw = HOME.getProperty(PLAYING_PROPERTY)
        HOME.clearProperty(PLAYING_PROPERTY)
        if not raw:
            return
        try:
            data = json.loads(raw)
            playing = self.getPlayingFile()
        except (ValueError, RuntimeError):
            return
        if time.time() - data.get("time", 0) > 300 or (data.get("file") and playing.split("|")[0] != data["file"]):
            return  # not what MK Cinema started
        self.current = data["play"]
        self.update()
        self.send("start")

    def onPlayBackPaused(self):
        self.update()
        self.send("pause")

    def onPlayBackResumed(self):
        self.update()
        self.send("start")

    def onPlayBackSeek(self, time_ms, offset_ms):
        self.update()

    def onPlayBackEnded(self):
        self.position = self.total
        self.finish()

    def onPlayBackStopped(self):
        self.finish()

    def onPlayBackError(self):
        self.current = None

    def finish(self):
        if self.current:
            self.send("stop")
        self.current = None


def main():
    monitor = xbmc.Monitor()
    player = Scrobbler()
    log("started")
    while not monitor.abortRequested():
        if player.current and player.isPlayingVideo():
            player.update()  # the position is gone once playback stops, so keep the last one
        if monitor.waitForAbort(10):
            break
    player.finish()


if __name__ == "__main__":
    main()
