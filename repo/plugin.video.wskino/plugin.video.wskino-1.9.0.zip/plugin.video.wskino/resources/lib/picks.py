# -*- coding: utf-8 -*-
"""Výběry: curated sections read from the GitHub repository, so they can change without a new version.

vybery.json lists the picks; a pick is a folder ("items") or one of these types:
  discover  media + TMDB discover query          e.g. Halloween films
  person    TMDB person id                       filmography, e.g. In memoriam
  titles    list of {"media", "id"}              hand-picked films and series; instead of "id" also
                                                 {"imdb": "tt…"} or {"search": "Title", "year": 2026};
                                                 "label" goes before the title, "note" after it
  episodes  file with shows and their episodes   e.g. Halloween episodes of series
A pick with "home": true is also shown in the main menu.
"from" / "to" limit when a pick is shown: "MM-DD" repeats every year (and may run over New Year,
e.g. 11-02 to 01-06), "YYYY-MM-DD" is a single date (e.g. In memoriam for one week) and
"velikonoce-30" counts days from Easter Sunday of that year.
oceneni.json holds generated picks (Oscars, film festivals) shown after those from vybery.json.
"""
import json
import os
import re
from datetime import date, timedelta

import requests

BASE_URL = "https://raw.githubusercontent.com/radimvmihalik/mk-cinema/main/"
FRESH_FOR = 30 * 60
BUNDLED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "picks")
GENERATED = "oceneni.json"
EASTER = re.compile(r"^velikonoce\s*(?:([+-])\s*(\d+))?$")


def load(storage, path="vybery.json", timeout=10):
    """The file from GitHub, cached for FRESH_FOR; offline: last copy, then the one shipped in the addon."""
    key = "picks:" + path
    data = storage.cache_get(key, FRESH_FOR)
    if data is not None:
        return data
    try:
        resp = requests.get(BASE_URL + path, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        storage.cache_set(key, data)
        return data
    except (requests.RequestException, ValueError):
        stale = storage.cache_get(key, 10 * 365 * 24 * 3600)
        if stale is not None:
            return stale
    bundled = os.path.join(BUNDLED, *path.split("/"))
    if os.path.isfile(bundled):
        with open(bundled, encoding="utf-8") as fh:
            return json.load(fh)
    return {}


def today():
    return date.today()


def easter(year):
    """Easter Sunday in the Gregorian calendar (anonymous Gregorian algorithm)."""
    a, b, c = year % 19, year // 100, year % 100
    d, e = divmod(b, 4)
    g = (8 * b + 13) // 25
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month, day = divmod(h + l - 7 * m + 114, 31)
    return date(year, month, day + 1)


def _bound(value, year):
    """'MM-DD', 'YYYY-MM-DD' or 'velikonoce±N' (as a date in year); anything else counts as not set."""
    value = str(value or "").strip().lower()
    moving = EASTER.match(value)
    if moving:
        shift = int(moving.group(2) or 0) * (-1 if moving.group(1) == "-" else 1)
        return (easter(year) + timedelta(days=shift)).isoformat()
    if len(value) == 10 and value[4] == value[7] == "-" and value.replace("-", "").isdigit():
        return value
    if len(value) == 5 and value[2] == "-" and value.replace("-", "").isdigit():
        return value
    return None


def active(pick, day=None):
    """Whether the pick is shown on day (default today), going by its "from" and "to" (both inclusive)."""
    day = day or today()
    start, end = _bound(pick.get("from"), day.year), _bound(pick.get("to"), day.year)
    full = day.isoformat()
    yearly = full[5:]
    if start and end and len(start) == len(end) == 5 and start > end:  # runs over New Year
        return yearly >= start or yearly <= end
    if start and (full if len(start) == 10 else yearly) < start:
        return False
    if end and (full if len(end) == 10 else yearly) > end:
        return False
    return True


def visible(items, day=None):
    """(index, pick) of the picks shown on day; indexes stay those in the file, so addresses keep working."""
    return [(index, pick) for index, pick in enumerate(items) if active(pick, day)]


def load_all(storage):
    """vybery.json followed by the generated picks; addresses index this joined list."""
    data = dict(load(storage))
    data["picks"] = list(data.get("picks", [])) + list(load(storage, GENERATED).get("picks", []))
    return data


def find(picks, address):
    """The pick at address '2' or '2/0' (indexes into nested items)."""
    node = {"items": picks.get("picks", [])}
    for index in address.split("/"):
        node = node.get("items", [])[int(index)]
    return node
