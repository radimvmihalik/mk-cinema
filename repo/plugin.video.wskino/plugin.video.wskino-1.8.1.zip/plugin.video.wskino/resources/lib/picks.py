# -*- coding: utf-8 -*-
"""Výběry: curated sections read from the GitHub repository, so they can change without a new version.

vybery.json lists the picks; a pick is a folder ("items") or one of these types:
  discover  media + TMDB discover query          e.g. Halloween films
  person    TMDB person id                       filmography, e.g. In memoriam
  titles    list of {"media", "id"}              hand-picked films and series
  episodes  file with shows and their episodes   e.g. Halloween episodes of series
A pick with "home": true is also shown in the main menu.
"from" / "to" limit when a pick is shown: "MM-DD" repeats every year (and may run over New Year,
e.g. 11-03 to 01-06), "YYYY-MM-DD" is a single date (e.g. In memoriam for one week).
"""
import json
import os
from datetime import date

import requests

BASE_URL = "https://raw.githubusercontent.com/radimvmihalik/mk-cinema/main/"
FRESH_FOR = 30 * 60
BUNDLED = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "picks")


def load(storage, path="vybery.json", timeout=10):
    """The file from GitHub, cached for FRESH_FOR; offline: last copy, then the one shipped in the addon."""
    key = "picks:" + path
    data = storage.cache_get(key, FRESH_FOR)
    if data is not None:
        return data
    try:
        resp = requests.get(BASE_URL + path, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        storage.cache_set(key, data)
        return data
    except (requests.RequestException, ValueError):
        stale = storage.cache_get(key, 10 * 365 * 24 * 3600)
        if stale is not None:
            return stale
    bundled = os.path.join(BUNDLED, *path.split("/"))
    if os.path.isfile(bundled):
        with open(bundled, encoding="utf-8") as fh:
            return json.load(fh)
    return {}


def today():
    return date.today()


def _bound(value):
    """'MM-DD' or 'YYYY-MM-DD' as written in vybery.json; anything else counts as not set."""
    value = str(value or "").strip()
    if len(value) == 10 and value[4] == value[7] == "-" and value.replace("-", "").isdigit():
        return value
    if len(value) == 5 and value[2] == "-" and value.replace("-", "").isdigit():
        return value
    return None


def active(pick, day=None):
    """Whether the pick is shown on day (default today), going by its "from" and "to" (both inclusive)."""
    start, end = _bound(pick.get("from")), _bound(pick.get("to"))
    full = (day or today()).isoformat()
    yearly = full[5:]
    if start and end and len(start) == len(end) == 5 and start > end:  # runs over New Year
        return yearly >= start or yearly <= end
    if start and (full if len(start) == 10 else yearly) < start:
        return False
    if end and (full if len(end) == 10 else yearly) > end:
        return False
    return True


def visible(items, day=None):
    """(index, pick) of the picks shown on day; indexes stay those in the file, so addresses keep working."""
    return [(index, pick) for index, pick in enumerate(items) if active(pick, day)]


def find(picks, address):
    """The pick at address '2' or '2/0' (indexes into nested items)."""
    node = {"items": picks.get("picks", [])}
    for index in address.split("/"):
        node = node.get("items", [])[int(index)]
    return node
