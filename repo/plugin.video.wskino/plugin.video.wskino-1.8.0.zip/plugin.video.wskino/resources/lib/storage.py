# -*- coding: utf-8 -*-
"""Small JSON files in the addon profile folder: login state, history, TMDB cache."""
import hashlib
import json
import os
import shutil
import time


class Storage(object):
    def __init__(self, folder):
        self.folder = folder
        self.cache_folder = os.path.join(folder, "cache")
        for path in (self.folder, self.cache_folder):
            if not os.path.isdir(path):
                os.makedirs(path)

    def _write(self, path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)

    def load(self, name, default=None):
        try:
            with open(os.path.join(self.folder, name + ".json"), encoding="utf-8") as fh:
                return json.load(fh)
        except (IOError, OSError, ValueError):
            return default

    def save(self, name, data):
        self._write(os.path.join(self.folder, name + ".json"), data)

    def push(self, name, entry, key, limit):
        """Put entry at the top of a stored list, dropping older entries with the same key."""
        items = [i for i in self.load(name, []) if i.get(key) != entry.get(key)]
        items.insert(0, entry)
        self.save(name, items[:limit])

    def _cache_path(self, key):
        return os.path.join(self.cache_folder, hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")

    def cache_get(self, key, ttl):
        path = self._cache_path(key)
        try:
            if time.time() - os.path.getmtime(path) > ttl:
                return None
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except (IOError, OSError, ValueError):
            return None

    def cache_set(self, key, data):
        self._write(self._cache_path(key), data)

    def cache_clear(self):
        shutil.rmtree(self.cache_folder, ignore_errors=True)
        os.makedirs(self.cache_folder)
