# -*- coding: utf-8 -*-
"""Pure-Python MD5-crypt ($1$), needed for the Webshare login.

Kodi on tvOS/Android/Windows has no usable `crypt` module, so the algorithm
(Poul-Henning Kamp's FreeBSD md5crypt) is implemented here directly.
"""
import hashlib

MAGIC = b"$1$"
_ITOA64 = b"./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


def _to64(value, length):
    out = bytearray()
    for _ in range(length):
        out.append(_ITOA64[value & 0x3F])
        value >>= 6
    return bytes(out)


def md5crypt(password, salt):
    """Return the full '$1$<salt>$<hash>' string, same as crypt(3)."""
    if isinstance(password, str):
        password = password.encode("utf-8")
    if isinstance(salt, str):
        salt = salt.encode("utf-8")
    if salt.startswith(MAGIC):
        salt = salt[len(MAGIC):]
    salt = salt.split(b"$", 1)[0][:8]

    ctx = password + MAGIC + salt
    final = hashlib.md5(password + salt + password).digest()
    remaining = len(password)
    while remaining > 0:
        ctx += final[:min(remaining, 16)]
        remaining -= 16

    i = len(password)
    while i:
        ctx += b"\x00" if i & 1 else password[:1]
        i >>= 1
    final = hashlib.md5(ctx).digest()

    # 1000 rounds to slow down brute force
    for i in range(1000):
        ctx1 = password if i & 1 else final
        if i % 3:
            ctx1 += salt
        if i % 7:
            ctx1 += password
        ctx1 += final if i & 1 else password
        final = hashlib.md5(ctx1).digest()

    f = final
    encoded = (
        _to64((f[0] << 16) | (f[6] << 8) | f[12], 4)
        + _to64((f[1] << 16) | (f[7] << 8) | f[13], 4)
        + _to64((f[2] << 16) | (f[8] << 8) | f[14], 4)
        + _to64((f[3] << 16) | (f[9] << 8) | f[15], 4)
        + _to64((f[4] << 16) | (f[10] << 8) | f[5], 4)
        + _to64(f[11], 2)
    )
    return (MAGIC + salt + b"$" + encoded).decode("ascii")
