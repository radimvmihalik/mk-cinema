# -*- coding: utf-8 -*-
"""Kodi UI: menus, TMDB library listings and Webshare playback."""
import json
import os
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import streams
from . import epg, picks
from .imdb import ImdbRatings
from .storage import Storage
from .tmdb import Tmdb, TmdbError, image
from .webshare import Webshare, WebshareError

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ICON = ADDON.getAddonInfo("icon")
ADDON_FANART = ADDON.getAddonInfo("fanart")
# Written by tools/build.sh from the local tmdb_key.txt; used when the setting is empty
BUNDLED_TMDB_KEY = os.path.join(ADDON.getAddonInfo("path"), "resources", "tmdb_key.txt")
MEDIA_PATH = os.path.join(ADDON.getAddonInfo("path"), "resources", "media")

# Values behind the <option> indexes in resources/settings.xml
TMDB_LANGUAGES = ["cs-CZ", "sk-SK", "en-US"]
PREFERRED_AUDIO = ["CZ", "SK", "EN", ""]
WS_LIMITS = [50, 100, 150]

DAY = 24 * 3600
FORMAT_NAMES = {"4k": "4K", "1080p": "1080p", "720p": "720p", "sd": "SD", "unknown": "neurčené kvality", "cam": "CAM (natočeno v kině)"}
MAX_STREAMS = 40  # sources shown per title
MAX_DETAILS = 25  # file_info requests per title: the top sources and those whose name says too little
UNAVAILABLE_DAYS = 3  # titles not found on Webshare are greyed out in lists for this long
PERSON_JOBS = {"Acting": "herec", "Directing": "režisér", "Writing": "scenárista", "Production": "producent",
               "Sound": "hudba", "Camera": "kameraman"}
PERSON_JOBS_FEMALE = {"herec": "herečka", "režisér": "režisérka", "scenárista": "scenáristka",
                      "producent": "producentka", "kameraman": "kameramanka"}
FOLDER_ACTIONS = {"root", "movies", "tvshows", "list", "genres", "countries", "search_menu", "search", "seasons", "episodes",
                  "history", "picks", "pick", "pick_titles", "pick_shows", "pick_episodes", "person", "person_list", "tv",
                  "tv_day", "tv_list", "tv_show", "collections", "collection", "charts", "chart", "chart_list"}
CHART_SIZE = 100
CHART_BOMB_GAP = 3  # points between IMDb and TMDB rating that mark a vote campaign
CHART_ACTOR_MIN_FILMS = 10
PLAY_ACTIONS = {"play", "play_file", "tv_play", "tv_play_episode"}
WEEKDAYS = ["pondělí", "úterý", "středa", "čtvrtek", "pátek", "sobota", "neděle"]

# Countries of origin offered in "Podle země"
COUNTRIES = [
    ("CZ", "Česko"), ("SK", "Slovensko"), ("US", "USA"), ("GB", "Velká Británie"), ("AR", "Argentina"),
    ("AU", "Austrálie"), ("BE", "Belgie"), ("BR", "Brazílie"), ("CN", "Čína"), ("DK", "Dánsko"), ("FI", "Finsko"),
    ("FR", "Francie"), ("IN", "Indie"), ("IE", "Irsko"), ("IS", "Island"), ("IT", "Itálie"), ("JP", "Japonsko"),
    ("KR", "Jižní Korea"), ("CA", "Kanada"), ("HU", "Maďarsko"), ("MX", "Mexiko"), ("DE", "Německo"),
    ("NL", "Nizozemsko"), ("NO", "Norsko"), ("NZ", "Nový Zéland"), ("PL", "Polsko"), ("AT", "Rakousko"),
    ("RU", "Rusko"), ("ES", "Španělsko"), ("SE", "Švédsko"), ("TH", "Thajsko"), ("TR", "Turecko"),
]

TV_LISTS = [
    ("Trendy tento týden", "trending/tv/week", {}),
    ("Populární", "tv/popular", {}),
    ("Nejlépe hodnocené", "tv/top_rated", {}),
    ("České seriály", "discover/tv", {"with_original_language": "cs", "sort_by": "popularity.desc"}),
    ("Slovenské seriály", "discover/tv", {"with_original_language": "sk", "sort_by": "popularity.desc"}),
]


def days_ago(days):
    return (date.today() - timedelta(days=days)).isoformat()


def movie_lists():
    """Films still only in cinemas are left out of the lists, Webshare doesn't have them yet."""
    # TMDB release types 4 = digital, 5 = physical (DVD/Blu-ray)
    online = {"with_release_type": "4|5", "release_date.lte": days_ago(0), "sort_by": "popularity.desc"}
    new_online = dict(online, sort_by="primary_release_date.desc", **{"release_date.gte": days_ago(120), "vote_count.gte": 20})
    older = {"primary_release_date.lte": days_ago(90), "sort_by": "popularity.desc"}
    return [
        ("Populární", "discover/movie", online),
        ("Nově vydané online", "discover/movie", new_online),
        ("Nejlépe hodnocené", "movie/top_rated", {}),
        ("České filmy", "discover/movie", dict(older, with_original_language="cs")),
        ("Slovenské filmy", "discover/movie", dict(older, with_original_language="sk")),
    ]


class UserError(Exception):
    """Problem the user can fix or should know about; shown as a notification."""

    def __init__(self, message, heading=None, error=True):
        super(UserError, self).__init__(message)
        self.heading = heading
        self.error = error


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)


def notify(msg, error=False, heading=None):
    xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, xbmcgui.NOTIFICATION_ERROR if error else ADDON_ICON, 6000)


def unique(values):
    seen, out = set(), []
    for v in values:
        key = streams.normalize(v)
        if key and key not in seen:  # titles in non-Latin scripts normalize to ""
            seen.add(key)
            out.append(v)
    return out


def decimal(value):
    return ("%.1f" % value).replace(".", ",")


def votes(count):
    if count >= 1000000:
        return "%s mil." % decimal(count / 1000000.0)
    if count >= 1000:
        return "%d tis." % (count // 1000)
    return str(count)


def day_label(day, today):
    """'Dnes · čtvrtek 23. 10.', 'Zítra · pátek 24. 10.', 'sobota 25. 10.'"""
    d = date(*map(int, day.split("-")))
    text = "%s %d. %d." % (WEEKDAYS[d.weekday()], d.day, d.month)
    offset = (d - date(*map(int, today.split("-")))).days
    return {0: "Dnes · " + text, 1: "Zítra · " + text}.get(offset, text)


def plural(count, one, few, many):
    return one if count == 1 else few if 2 <= count <= 4 else many


@contextmanager
def busy():
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        yield
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


def set_video_info(li, info):
    """InfoTag API (Kodi 20+) with a fallback to setInfo for Kodi 19."""
    info = {k: v for k, v in info.items() if v not in (None, "", [])}
    try:
        tag = li.getVideoInfoTag()
    except AttributeError:
        info.pop("tmdb", None)
        info.pop("ratings", None)
        li.setInfo("video", info)
        return
    setters = {
        "mediatype": tag.setMediaType,
        "title": tag.setTitle,
        "originaltitle": tag.setOriginalTitle,
        "tvshowtitle": tag.setTvShowTitle,
        "plot": tag.setPlot,
        "premiered": tag.setPremiered,
        "aired": tag.setFirstAired,
        "genre": tag.setGenres,
        "year": lambda v: tag.setYear(int(v)),
        "season": lambda v: tag.setSeason(int(v)),
        "episode": lambda v: tag.setEpisode(int(v)),
        "rating": lambda v: tag.setRating(float(v), int(info.get("votes") or 0)),
        "ratings": lambda v: tag.setRatings(v, "imdb" if "imdb" in v else "themoviedb"),
        "studio": tag.setStudios,
        "duration": lambda v: tag.setDuration(int(v)),
        "tmdb": lambda v: tag.setUniqueIDs({"tmdb": str(v)}, "tmdb"),
    }
    for key, value in info.items():
        if key in setters:
            setters[key](value)


TRACK_LANGUAGES = {
    "CZ": {"cze", "ces", "cs", "czech", "cestina", "čeština"},
    "SK": {"slo", "slk", "sk", "slovak", "slovencina", "slovenčina"},
}


def _find_track(tracks, codes):
    return next((i for i, t in enumerate(tracks) if t.strip().lower() in codes), None)


def pick_audio_and_subtitles(preferred):
    """Once playback runs: dubbing in the preferred language with subtitles off, otherwise
    the original audio with subtitles in that language (the other of CZ/SK as a fallback)."""
    if preferred not in TRACK_LANGUAGES:
        return
    other = "SK" if preferred == "CZ" else "CZ"
    player, monitor = xbmc.Player(), xbmc.Monitor()
    for _ in range(120):  # wait up to a minute for the stream to open
        try:
            if player.isPlayingVideo() and player.getAvailableAudioStreams():
                break
        except RuntimeError:
            pass
        if monitor.waitForAbort(0.5):
            return
    else:
        return
    try:
        audio = player.getAvailableAudioStreams()
        subtitles = player.getAvailableSubtitleStreams()
        dub = _find_track(audio, TRACK_LANGUAGES[preferred])
        if dub is not None:
            player.setAudioStream(dub)
            player.showSubtitles(False)
            return
        for lang in (preferred, other):
            sub = _find_track(subtitles, TRACK_LANGUAGES[lang])
            if sub is not None:
                dubbed = TRACK_LANGUAGES["CZ"] | TRACK_LANGUAGES["SK"]
                original = next((i for i, t in enumerate(audio) if t.strip().lower() not in dubbed), None)
                if original is not None:
                    player.setAudioStream(original)
                player.setSubtitleStream(sub)
                player.showSubtitles(True)
                return
        other_dub = _find_track(audio, TRACK_LANGUAGES[other])
        if other_dub is not None:  # no subtitles to read: a Slovak/Czech dub beats not understanding
            player.setAudioStream(other_dub)
    except RuntimeError as exc:  # playback stopped meanwhile
        log("could not pick audio/subtitles: %s" % exc, xbmc.LOGWARNING)


class Plugin(object):
    def __init__(self, argv):
        self.base_url = argv[0]
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip("?")))
        self.action = self.params.get("action", "root")
        self.storage = Storage(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")))
        self._tmdb = None
        self._imdb = None
        self.refresh_imdb = False
        self._unavailable = None

    # ------------------------------------------------------------------ helpers
    def url(self, **params):
        return self.base_url + "?" + urlencode(params)

    def setting(self, key):
        return ADDON.getSetting(key)

    def setting_choice(self, key, choices):
        try:
            return choices[int(self.setting(key))]
        except (ValueError, IndexError):
            return choices[0]

    def tmdb_key(self):
        """The built-in key; the hidden setting only serves tests and builds without one."""
        if os.path.isfile(BUNDLED_TMDB_KEY):
            with open(BUNDLED_TMDB_KEY, encoding="utf-8") as fh:
                return fh.read().strip()
        return self.setting("tmdb_key").strip()

    @property
    def imdb(self):
        if self._imdb is None:
            self._imdb = ImdbRatings(self.storage.folder)
        return self._imdb

    @property
    def tmdb(self):
        if self._tmdb is None:
            key = self.tmdb_key()
            if not key:
                raise UserError("Doplněk nemá TMDB klíč, sestav ho znovu přes tools/build.sh.")
            self._tmdb = Tmdb(key, self.setting_choice("tmdb_lang", TMDB_LANGUAGES), self.storage)
        return self._tmdb

    def webshare(self, login=False, fresh=False):
        """Webshare client; with login=True it guarantees a session token."""
        state = self.storage.load("state", {})
        if not state.get("uuid"):
            state["uuid"] = str(uuid.uuid4())
            self.storage.save("state", state)
        user, password = self.setting("ws_user").strip(), self.setting("ws_pass")
        token = state.get("token", "") if state.get("token_user") == user else ""
        ws = Webshare(token=token, device_uuid=state["uuid"])
        if login and (fresh or not token):
            if not user or not password:
                raise UserError("Nejdřív v nastavení vyplň jméno a heslo k Webshare.")
            try:
                ws.login(user, password)
            except WebshareError as exc:
                raise UserError("Přihlášení k Webshare selhalo: %s" % exc)
            state.update(token=ws.token, token_user=user)
            self.storage.save("state", state)
            try:
                if ws.user_data().get("vip") != "1":
                    notify("Účet Webshare nemá aktivní VIP – přehrávání bude pomalé.")
            except WebshareError:
                pass
        return ws

    def item(self, label, params, folder=True, art=None, info=None, playable=False, context=None, icon=None):
        li = xbmcgui.ListItem(label, offscreen=True)
        art = dict(art or {})
        if icon:
            art.setdefault("icon", icon)
            art.setdefault("thumb", icon)
        if not art.get("fanart"):
            art["fanart"] = ADDON_FANART
        li.setArt(art)
        if info:
            set_video_info(li, info)
        if playable:
            li.setProperty("IsPlayable", "true")
            folder = False
        if context:
            li.addContextMenuItems(context)
        xbmcplugin.addDirectoryItem(self.handle, self.url(**params), li, folder)

    def end(self, content=None, cache=True):
        if content:
            xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def fail(self):
        if self.handle < 0:
            return
        if self.action in PLAY_ACTIONS:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        elif self.action in FOLDER_ACTIONS:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    @staticmethod
    def art_for(p):
        poster = image(p.get("poster"))
        still = image(p.get("still"), "w780")
        return {"poster": poster, "thumb": still or poster, "fanart": image(p.get("fanart"), "w1280")}

    @staticmethod
    def play_label(p):
        if p.get("media") == "episode":
            return "%s %sx%02d %s" % (p.get("title", ""), p.get("season"), int(p.get("episode", 0)), p.get("ename", ""))
        if p.get("media") == "movie":
            return "%s (%s)" % (p.get("title"), p.get("year")) if p.get("year") else p.get("title", "")
        return p.get("name", "")

    @staticmethod
    def play_info(p):
        if p.get("media") == "episode":
            return {"mediatype": "episode", "title": p.get("ename") or p.get("title"), "tvshowtitle": p.get("title"),
                    "season": p.get("season"), "episode": p.get("episode")}
        if p.get("media") == "movie":
            return {"mediatype": "movie", "title": p.get("title"), "originaltitle": p.get("otitle"), "year": p.get("year")}
        return {"mediatype": "video", "title": p.get("name")}

    def playable(self, label, play, info, extra_context=None):
        context = [("Vybrat zdroj ručně", "PlayMedia(%s)" % self.url(**dict(play, select=1)))]
        if play.get("media") == "movie":
            ws_query = "%s %s" % (play["title"], play.get("year", ""))
        else:
            ws_query = "%s s%02de%02d" % (play["title"], int(play["season"]), int(play["episode"]))
        context.append(("Hledat přímo na Webshare", "Container.Update(%s)" % self.url(action="search", media="ws", query=ws_query.strip())))
        if self.availability_key(play) in self.unavailable:
            label = "[COLOR grey]%s  (není na Webshare)[/COLOR]" % label
        self.item(label, play, art=self.art_for(play), info=info, playable=True, context=context + (extra_context or []))

    @staticmethod
    def availability_key(p):
        if p.get("media") == "episode":
            return "episode:%s:%s:%s" % (p.get("id"), p.get("season"), p.get("episode"))
        return "movie:%s" % p.get("id")

    @property
    def unavailable(self):
        """Titles that recently had no sources on Webshare: {key: time it was checked}."""
        if self._unavailable is None:
            limit = time.time() - UNAVAILABLE_DAYS * DAY
            self._unavailable = {k: t for k, t in self.storage.load("unavailable", {}).items() if t > limit}
        return self._unavailable

    def remember_availability(self, p, available):
        key = self.availability_key(p)
        if available:
            self.unavailable.pop(key, None)
        else:
            self.unavailable[key] = time.time()
        self.storage.save("unavailable", self.unavailable)

    # ------------------------------------------------------------------ menus
    def do_root(self):
        if not self.setting("ws_user") or not self.setting("ws_pass"):
            self.item("[COLOR yellow]Přihlas se ke svému účtu Webshare[/COLOR]", {"action": "settings"}, folder=False, icon="DefaultUser.png")
        if not self.tmdb_key():
            self.item("[COLOR yellow]Doplněk nemá TMDB klíč, sestav ho znovu přes tools/build.sh[/COLOR]", {"action": "settings"}, folder=False, icon="DefaultAddonProgram.png")
        all_picks = picks.load(self.storage).get("picks", [])
        for index, pick in enumerate(all_picks):
            if pick.get("home"):
                self.pick_item(pick, str(index))
        self.item("Filmy", {"action": "movies"}, icon="DefaultMovies.png")
        self.item("Seriály", {"action": "tvshows"}, icon="DefaultTVShows.png")
        self.item("Výběry", {"action": "picks"}, icon="DefaultFavourites.png")
        self.item("Žebříčky IMDb", {"action": "charts"}, icon="DefaultMusicTop100.png")
        self.item("Dnes v TV", {"action": "tv"}, icon="DefaultTVShows.png")
        self.item("Herci a tvůrci", {"action": "search_menu", "media": "person"}, icon="DefaultActor.png")
        self.item("Naposledy přehrané", {"action": "history"}, icon="DefaultRecentlyAddedMovies.png")
        self.item("Hledat přímo na Webshare", {"action": "search_menu", "media": "ws"}, icon="DefaultAddonsSearch.png")
        self.item("Můj účet Webshare", {"action": "account"}, folder=False, icon="DefaultUser.png")
        self.item("Nastavení", {"action": "settings"}, folder=False, icon="DefaultAddonProgram.png")
        self.end()

    def do_movies(self):
        self.catalog_menu("movie", movie_lists(), "DefaultMovies.png")

    def do_tvshows(self):
        self.catalog_menu("tv", TV_LISTS, "DefaultTVShows.png")

    def catalog_menu(self, media, lists, icon):
        self.item("Hledat", {"action": "search_menu", "media": media}, icon="DefaultAddonsSearch.png")
        if media == "movie":
            self.item("Filmové série", {"action": "collections"}, icon="DefaultSets.png")
        for label, path, query in lists:
            self.item(label, {"action": "list", "media": media, "path": path, "q": json.dumps(query)}, icon=icon)
        self.item("Žánry", {"action": "genres", "media": media}, icon="DefaultGenre.png")
        self.item("Podle země", {"action": "countries", "media": media}, icon="DefaultCountry.png")
        self.end()

    # ------------------------------------------------------------------ Výběry (from GitHub)
    def do_picks(self):
        for index, pick in enumerate(picks.load(self.storage).get("picks", [])):
            self.pick_item(pick, str(index))
        self.end()

    def do_pick(self):
        address = self.params["address"]
        for index, pick in enumerate(picks.find(picks.load(self.storage), address).get("items", [])):
            self.pick_item(pick, "%s/%d" % (address, index))
        self.end()

    def pick_label(self, pick):
        return "[COLOR %s]%s[/COLOR]" % (pick["color"], pick["title"]) if pick.get("color") else pick["title"]

    def pick_item(self, pick, address):
        kind = "folder" if "items" in pick else pick.get("type")
        if kind == "folder":
            params = {"action": "pick", "address": address}
        elif kind == "discover":
            params = self.discover_params(pick.get("media", "movie"), pick.get("query", {}))
        elif kind == "person":
            params = {"action": "person", "id": pick["id"]}
        elif kind == "titles":
            params = {"action": "pick_titles", "address": address}
        elif kind == "episodes":
            params = {"action": "pick_shows", "file": pick["file"]}
        else:
            log("unknown pick type %r in vybery.json" % kind, xbmc.LOGWARNING)
            return
        icon = {"person": "DefaultActor.png", "episodes": "DefaultTVShows.png"}.get(kind, "DefaultGenre.png")
        self.item(self.pick_label(pick), params, icon=pick.get("icon") or icon)

    def do_pick_titles(self):
        pick = picks.find(picks.load(self.storage), self.params["address"])
        for media in ("movie", "tv"):
            ids = [t["id"] for t in pick.get("titles", []) if t.get("media", "movie") == media]
            details = self.details(media, ids)
            results = [dict(d, genre_ids=[g["id"] for g in d.get("genres", [])]) for d in (details[i] for i in ids) if d.get("id")]
            self.add_tmdb_items(media, results)
        self.end("movies")

    def episode_shows(self):
        return picks.load(self.storage, self.params["file"]) or []

    def do_pick_shows(self):
        for show in self.episode_shows():
            count = len(show["episodes"])
            label = "%s  [COLOR grey](%d %s)[/COLOR]" % (show["title"], count, plural(count, "díl", "díly", "dílů"))
            info = {"mediatype": "tvshow", "title": show["title"], "tvshowtitle": show["title"],
                    "originaltitle": show["otitle"], "tmdb": show["id"]}
            self.item(label, {"action": "pick_episodes", "file": self.params["file"], "id": show["id"]},
                      art=self.art_for(show), info=info)
        self.end("tvshows")

    def do_pick_episodes(self):
        show = next(s for s in self.episode_shows() if str(s["id"]) == self.params["id"])
        for e in show["episodes"]:
            play = {"action": "play", "media": "episode", "id": show["id"], "title": show["title"], "otitle": show["otitle"],
                    "season": e["season"], "episode": e["episode"], "ename": e["name"], "ename_en": e.get("name_en", ""),
                    "poster": show["poster"], "fanart": show["fanart"], "still": e.get("still", "")}
            info = {"mediatype": "episode", "title": e["name"], "tvshowtitle": show["title"], "season": e["season"],
                    "episode": e["episode"], "plot": e.get("plot"), "aired": e.get("aired")}
            self.playable("%dx%02d  %s" % (e["season"], e["episode"], e["name"]), play, info)
        self.end("episodes")

    # ------------------------------------------------------------------ IMDb charts (zebricky.json from GitHub)
    def chart(self):
        data = picks.load(self.storage, "zebricky.json")
        chart = next((c for c in data.get("charts", []) if c["id"] == self.params["id"]), None)
        if chart is None:
            raise UserError("Tento žebříček teď není k dispozici.")
        return chart, data.get("updated", "")

    def do_charts(self):
        data = picks.load(self.storage, "zebricky.json")
        updated = data.get("updated", "")
        for chart in data.get("charts", []):
            plot = "Podle hodnocení IMDb%s." % (", aktualizováno " + ".".join(reversed(updated.split("-"))) if updated else "")
            if chart.get("person"):
                plot += "\nPrůměr hodnocení filmů, kde měli hlavní roli (aspoň %d filmů)." % CHART_ACTOR_MIN_FILMS
            self.item(chart["title"], {"action": "chart", "id": chart["id"]}, icon="DefaultMusicTop100.png",
                      info={"mediatype": "video", "title": chart["title"], "plot": plot})
        self.end()

    def do_chart(self):
        chart, _ = self.chart()
        for order, label in (("best", "Nejlepších 100"), ("worst", "Nejhorších 100")):
            self.item(label, {"action": "chart_list", "id": chart["id"], "order": order}, icon="DefaultMusicTop100.png")
        self.end()

    def imdb_lookup(self, entries, key):
        """(entry, TMDB result) for IMDb ids, in order; asks TMDB in batches only as far as needed for 100."""
        def find(entry):
            try:
                data = self.tmdb.get("find/%s" % entry[0], ttl=30 * DAY, external_source="imdb_id")
            except TmdbError:
                data = {}
            return entry, (data.get(key(entry)) or [None])[0]

        found = []
        with busy(), ThreadPoolExecutor(max_workers=8) as pool:
            for start in range(0, len(entries), 40):
                found += [f for f in pool.map(find, entries[start:start + 40]) if f[1]]
                if len(found) >= CHART_SIZE + 20:
                    break
        return found

    def do_chart_list(self):
        chart, _ = self.chart()
        entries = chart.get(self.params["order"], [])
        if chart.get("person"):
            for rank, (entry, person) in enumerate(self.imdb_lookup(entries, lambda e: "person_results")[:CHART_SIZE], 1):
                photo = image(person.get("profile_path"))
                name = person.get("name") if streams.is_latin(person.get("name")) and person.get("name") else entry[3]
                label = "%d. %s  [COLOR grey]průměr %s · %d %s[/COLOR]" % (rank, name, decimal(entry[1]),
                                                                            entry[2], plural(entry[2], "film", "filmy", "filmů"))
                self.item(label, {"action": "person", "id": person["id"]}, art={"thumb": photo, "poster": photo}, icon="DefaultActor.png")
            self.end("videos")
            return
        results = []
        for entry, r in self.imdb_lookup(entries, lambda e: "movie_results" if e[3] == "movie" else "tv_results"):
            if r.get("vote_count", 0) >= 50 and abs((r.get("vote_average") or 0) - entry[1]) > CHART_BOMB_GAP:
                continue  # IMDb and TMDB disagree a lot: rating pushed by a vote campaign
            results.append(dict(r, _media=entry[3], _prefix="%d. " % (len(results) + 1),
                                _suffix="  [COLOR grey]IMDb %s[/COLOR]" % decimal(entry[1])))
            if len(results) == CHART_SIZE:
                break
        self.add_tmdb_items(None, results)
        self.end("movies")

    # ------------------------------------------------------------------ film series (TMDB collections)
    def do_collections(self):
        self.item("[B]Hledat sérii…[/B]", {"action": "search_menu", "media": "collection"}, icon="DefaultAddonsSearch.png")
        series = picks.load(self.storage, "serie.json").get("series", [])
        for c in sorted(series, key=lambda c: streams.czech_sort_key(c["title"])):
            label = "%s  [COLOR grey](%d %s)[/COLOR]" % (c["title"], c["parts"], plural(c["parts"], "film", "filmy", "filmů"))
            self.item(label, {"action": "collection", "id": c["id"]}, art=self.art_for(c), icon="DefaultSets.png")
        self.end("movies")

    def add_collections(self, found):
        for c in found:
            if streams.is_latin(c.get("name")):
                art = self.art_for({"poster": c.get("poster_path"), "fanart": c.get("backdrop_path")})
                self.item(c["name"], {"action": "collection", "id": c["id"]}, art=art, icon="DefaultSets.png")
        self.end("movies")

    def do_collection(self):
        """All films of a series in the order they came out, numbered."""
        parts = self.tmdb.get("collection/%s" % self.params["id"], ttl=DAY).get("parts", [])
        parts = sorted(parts, key=lambda part: part.get("release_date") or "9999")
        for number, part in enumerate(parts, 1):
            part["_prefix"] = "%d. " % number
        self.add_tmdb_items("movie", parts)
        self.end("movies")

    # ------------------------------------------------------------------ actors, directors
    def add_people(self, people):
        for person in people:
            job = PERSON_JOBS.get(person.get("known_for_department"), "")
            if job and person.get("gender") == 1:
                job = PERSON_JOBS_FEMALE.get(job, job)
            label = "%s  [COLOR grey]%s[/COLOR]" % (person["name"], job) if job else person["name"]
            known = ", ".join(k.get("title") or k.get("name") or "" for k in person.get("known_for", [])[:3])
            photo = image(person.get("profile_path"))
            self.item(label, {"action": "person", "id": person["id"]}, art={"thumb": photo, "poster": photo},
                      info={"mediatype": "video", "title": person["name"], "plot": "Známý z: " + known if known else ""},
                      icon="DefaultActor.png")
        self.end("videos")

    def person(self):
        return self.tmdb.get("person/%s" % self.params["id"], ttl=DAY, append_to_response="combined_credits")

    def do_person(self):
        person = self.person()
        credits = person.get("combined_credits", {})
        photo = image(person.get("profile_path"))
        life = " – ".join(d[:4] for d in (person.get("birthday"), person.get("deathday")) if d)
        plot = ("[COLOR grey]%s[/COLOR]\n\n" % life if life else "") + (person.get("biography") or "")
        for media, label in (("movie", "Filmy"), ("tv", "Seriály")):
            count = len(self.filmography(credits, media))
            if count:
                self.item("%s  [COLOR grey](%d)[/COLOR]" % (label, count), {"action": "person_list", "id": self.params["id"], "media": media},
                          art={"thumb": photo, "poster": photo}, info={"mediatype": "video", "title": person.get("name"), "plot": plot},
                          icon="DefaultActor.png")
        self.end()

    @staticmethod
    def filmography(credits, media):
        """Films or series of a person, each once, without talk shows and appearances as themselves."""
        seen, found = set(), []
        for c in credits.get("cast", []) + credits.get("crew", []):
            if c.get("media_type") != media or c["id"] in seen:
                continue
            if media == "tv" and (set(c.get("genre_ids", [])) & {10763, 10764, 10767} or "self" in (c.get("character") or "").lower()):
                continue  # news, reality and talk shows
            seen.add(c["id"])
            found.append(c)
        return sorted(found, key=lambda c: c.get("popularity", 0), reverse=True)[:60]

    def do_person_list(self):
        media = self.params["media"]
        self.add_tmdb_results(media, {"results": self.filmography(self.person().get("combined_credits", {}), media)})

    def do_genres(self):
        media = self.params["media"]
        anime = {"with_genres": 16, "with_original_language": "ja"}
        self.item("Anime", self.discover_params(media, anime), icon="DefaultGenre.png")
        for genre_id, name in sorted(self.genre_names(media).items(), key=lambda g: g[1]):
            self.item(name, self.discover_params(media, {"with_genres": genre_id}), icon="DefaultGenre.png")
        self.end()

    def do_countries(self):
        media = self.params["media"]
        for code, name in COUNTRIES:
            params = self.discover_params(media, {"with_origin_country": code})
            params["country"] = code  # list only titles whose main country this is
            self.item(name, params, icon="DefaultCountry.png")
        self.end()

    @staticmethod
    def discover_params(media, query):
        query = dict(query)
        query.setdefault("sort_by", "popularity.desc")
        query.setdefault("vote_count.gte", 50 if media == "movie" else 20)
        if media == "movie":
            query.setdefault("primary_release_date.lte", days_ago(90))
        return {"action": "list", "media": media, "path": "discover/" + media, "q": json.dumps(query)}

    def genre_names(self, media):
        try:
            data = self.tmdb.get("genre/%s/list" % media, ttl=7 * DAY)
        except TmdbError:
            return {}
        return {g["id"]: g["name"] for g in data.get("genres", [])}

    # ------------------------------------------------------------------ TMDB listings
    def do_list(self):
        page = int(self.params.get("page", 1))
        query = json.loads(self.params.get("q") or "{}")
        data = self.tmdb.get(self.params["path"], page=page, **query)
        self.add_tmdb_results(self.params["media"], data)

    def add_tmdb_results(self, media, data):
        self.add_tmdb_items(media, data.get("results", []))
        page, pages = int(data.get("page", 1)), min(int(data.get("total_pages", 1)), 500)
        if page < pages:
            self.item("[B]Další strana »[/B]  (%d/%d)" % (page + 1, pages), dict(self.params, page=page + 1), icon="DefaultFolder.png")
        self.end("movies" if media == "movie" else "tvshows")

    def add_tmdb_items(self, media, results):
        """Films or series; with media=None each result says its own kind in "_media" (mixed lists)."""
        kind_of = lambda r: r.get("_media") or media
        genres, details, english = {}, {}, {}
        for kind in {kind_of(r) for r in results}:
            ids = [r["id"] for r in results if kind_of(r) == kind]
            genres[kind] = self.genre_names(kind)
            for tmdb_id, d in self.details(kind, ids, append_to_response="watch/providers,external_ids").items():
                details[kind, tmdb_id] = d
            # No Czech title -> TMDB gives the original one, which may be in a script Kodi's font lacks
            foreign = [r["id"] for r in results if kind_of(r) == kind and not streams.is_latin(r.get("title") or r.get("name"))]
            for tmdb_id, d in self.details(kind, foreign, language="en-US").items():
                english[kind, tmdb_id] = d
        imdb_ids = {key: d.get("imdb_id") or d.get("external_ids", {}).get("imdb_id") for key, d in details.items()}
        ratings = self.imdb.get([i for i in imdb_ids.values() if i])
        if not self.imdb.is_fresh():
            self.refresh_imdb = True
        country = self.params.get("country")
        for result in results:
            kind = kind_of(result)
            d = details.get((kind, result["id"]), {})
            origin = d.get("origin_country") or result.get("origin_country") or [c["iso_3166_1"] for c in d.get("production_countries", [])]
            if country and origin and origin[0] != country:
                continue
            en = english.get((kind, result["id"]), {})
            for key in ("title", "name"):
                if en.get(key) and streams.is_latin(en[key]):
                    result = dict(result, **{key: en[key]})
            rating = ratings.get(imdb_ids.get((kind, result["id"])))
            if kind == "movie":
                self.add_movie(result, genres[kind], d, rating)
            else:
                self.add_show(result, genres[kind], d, rating)

    def details(self, media, ids, **params):
        """TMDB details of list items (studio, TV network, Czech streaming services, IMDb id, runtime), cached for a week."""
        def fetch(tmdb_id):
            try:
                return tmdb_id, self.tmdb.get("%s/%s" % (media, tmdb_id), ttl=7 * DAY, **params)
            except TmdbError:
                return tmdb_id, {}

        with ThreadPoolExecutor(max_workers=8) as pool:
            return dict(pool.map(fetch, ids))

    @staticmethod
    def described_plot(title, original_title, details, overview, r, imdb_rating):
        """Original title, rating, studio and where it streams, above the plot (the skin shows the plot on the left)."""
        lines = []
        if original_title and streams.is_latin(original_title) and streams.normalize(original_title) != streams.normalize(title):
            lines.append("[COLOR grey]Originál:[/COLOR] %s" % original_title)
        scores = []
        if imdb_rating:
            scores.append("IMDb %s (%s)" % (decimal(imdb_rating[0]), votes(imdb_rating[1])))
        if r.get("vote_count"):
            scores.append("TMDB %s" % decimal(r.get("vote_average") or 0))
        if scores:
            lines.append("[COLOR grey]Hodnocení:[/COLOR] %s" % " · ".join(scores))
        networks = [n["name"] for n in details.get("networks", []) if streams.is_latin(n["name"])][:2]
        if networks:
            lines.append("[COLOR grey]Stanice:[/COLOR] %s" % ", ".join(networks))
        companies = [c["name"] for c in details.get("production_companies", []) if streams.is_latin(c["name"])][:2]
        if companies:
            lines.append("[COLOR grey]Studio:[/COLOR] %s" % ", ".join(companies))
        providers = details.get("watch/providers", {}).get("results", {}).get("CZ", {}).get("flatrate", [])
        if providers:
            lines.append("[COLOR grey]Streamuje:[/COLOR] %s" % ", ".join(p["provider_name"] for p in providers[:3]))
        return "\n".join(lines) + ("\n\n" if lines and overview else "") + (overview or "")

    @staticmethod
    def ratings(r, imdb_rating):
        ratings = {}
        if imdb_rating:
            ratings["imdb"] = (float(imdb_rating[0]), int(imdb_rating[1]))
        if r.get("vote_count"):
            ratings["themoviedb"] = (float(r.get("vote_average") or 0), int(r["vote_count"]))
        return ratings

    def add_movie(self, r, genres, details, imdb_rating=None):
        title = r.get("title") or r.get("original_title") or ""
        year = (r.get("release_date") or "")[:4]
        play = {"action": "play", "media": "movie", "id": r["id"], "title": title,
                "otitle": r.get("original_title") or "", "year": year,
                "poster": r.get("poster_path") or "", "fanart": r.get("backdrop_path") or ""}
        info = {"mediatype": "movie", "title": title, "originaltitle": play["otitle"], "year": year,
                "plot": self.described_plot(title, play["otitle"], details, r.get("overview"), r, imdb_rating),
                "premiered": r.get("release_date"), "ratings": self.ratings(r, imdb_rating),
                "genre": [genres[g] for g in r.get("genre_ids", []) if g in genres], "tmdb": r["id"],
                "studio": [c["name"] for c in details.get("production_companies", []) if streams.is_latin(c["name"])][:3],
                "duration": (details.get("runtime") or 0) * 60}
        self.playable(r.get("_prefix", "") + ("%s (%s)" % (title, year) if year else title) + r.get("_suffix", ""), play, info)

    def add_show(self, r, genres, details, imdb_rating=None):
        name = r.get("name") or r.get("original_name") or ""
        year = (r.get("first_air_date") or "")[:4]
        params = {"action": "seasons", "id": r["id"], "title": name, "otitle": r.get("original_name") or "",
                  "poster": r.get("poster_path") or "", "fanart": r.get("backdrop_path") or ""}
        info = {"mediatype": "tvshow", "title": name, "tvshowtitle": name, "originaltitle": params["otitle"],
                "year": year, "plot": self.described_plot(name, params["otitle"], details, r.get("overview"), r, imdb_rating),
                "premiered": r.get("first_air_date"), "ratings": self.ratings(r, imdb_rating),
                "genre": [genres[g] for g in r.get("genre_ids", []) if g in genres], "tmdb": r["id"],
                "studio": [n["name"] for n in details.get("networks", []) if streams.is_latin(n["name"])][:3]}
        label = r.get("_prefix", "") + ("%s (%s)" % (name, year) if year else name) + r.get("_suffix", "")
        self.item(label, params, art=self.art_for(params), info=info)

    def do_seasons(self):
        p = self.params
        show = self.tmdb.get("tv/%s" % p["id"], ttl=DAY)
        title = p.get("title") or show.get("name", "")
        fanart = show.get("backdrop_path") or p.get("fanart", "")
        seasons = sorted(show.get("seasons", []), key=lambda s: (s.get("season_number") == 0, s.get("season_number")))
        for s in seasons:
            count = s.get("episode_count") or 0
            if not count:
                continue
            number = s.get("season_number")
            season_name = s.get("name") if streams.is_latin(s.get("name")) and s.get("name") else "Řada %d" % number
            label = "%s  [COLOR grey](%d %s)[/COLOR]" % (season_name, count, plural(count, "díl", "díly", "dílů"))
            params = {"action": "episodes", "id": p["id"], "season": number, "title": title,
                      "otitle": p.get("otitle") or show.get("original_name", ""), "fanart": fanart,
                      "poster": s.get("poster_path") or show.get("poster_path") or ""}
            info = {"mediatype": "season", "title": s.get("name"), "tvshowtitle": title, "season": number,
                    "plot": s.get("overview") or show.get("overview"), "premiered": s.get("air_date")}
            self.item(label, params, art=self.art_for(params), info=info)
        self.end("seasons")

    def do_episodes(self):
        p = self.params
        season = int(p["season"])
        data = self.tmdb.get("tv/%s/season/%d" % (p["id"], season), ttl=DAY)
        today = date.today().isoformat()
        for e in data.get("episodes", []):
            number = e.get("episode_number")
            name = e.get("name") or ""
            if not streams.is_latin(name):
                name = "Díl %d" % number
            aired = e.get("air_date") or ""
            label = "%dx%02d  %s" % (season, number, name)
            if not aired or aired > today:
                label = "[COLOR grey]%s[/COLOR]" % label
            play = {"action": "play", "media": "episode", "id": p["id"], "title": p["title"],
                    "otitle": p.get("otitle", ""), "season": season, "episode": number, "ename": name,
                    "poster": p.get("poster", ""), "fanart": p.get("fanart", ""), "still": e.get("still_path") or ""}
            info = {"mediatype": "episode", "title": name, "tvshowtitle": p["title"], "season": season,
                    "episode": number, "plot": e.get("overview"), "aired": aired,
                    "rating": e.get("vote_average"), "votes": e.get("vote_count")}
            self.playable(label, play, info)
        self.end("episodes")

    # ------------------------------------------------------------------ search
    def do_search_menu(self):
        media = self.params["media"]
        self.item("[B]Nové hledání…[/B]", {"action": "new_search", "media": media}, folder=False, icon="DefaultAddonsSearch.png")
        clear = [("Smazat historii hledání", "RunPlugin(%s)" % self.url(action="search_clear", media=media))]
        for entry in self.storage.load("searches_" + media, []):
            self.item(entry["query"], {"action": "search", "media": media, "query": entry["query"]},
                      icon="DefaultAddonsSearch.png", context=clear)
        self.end(cache=False)

    def do_new_search(self):
        media = self.params["media"]
        query = xbmcgui.Dialog().input("Hledat").strip()
        if not query:
            return
        self.storage.push("searches_" + media, {"query": query}, "query", 20)
        xbmc.executebuiltin("Container.Update(%s)" % self.url(action="search", media=media, query=query))

    def do_search_clear(self):
        self.storage.save("searches_" + self.params["media"], [])
        xbmc.executebuiltin("Container.Refresh")

    def do_search(self):
        media, query = self.params["media"], self.params["query"]
        page = int(self.params.get("page", 1))
        if media == "ws":
            self.webshare_files(query, page)
        elif media == "person":
            self.add_people(self.tmdb.get("search/person", ttl=DAY, query=query).get("results", []))
        elif media == "collection":
            self.add_collections(self.tmdb.get("search/collection", ttl=DAY, query=query).get("results", []))
        else:
            self.add_tmdb_results(media, self.tmdb.get("search/" + media, ttl=DAY, query=query, page=page))

    def webshare_files(self, query, page):
        limit = 50
        files, total = Webshare().search(query, limit=limit, offset=(page - 1) * limit)
        for f in files:
            if f.get("password") == "1":
                continue
            name = f.get("name", "")
            play = {"action": "play_file", "ident": f.get("ident", ""), "name": name}
            label = "%s  [COLOR grey]%s[/COLOR]" % (name, streams.format_size(int(f.get("size") or 0)))
            self.item(label, play, art={"thumb": f.get("img", ""), "icon": f.get("img", "")},
                      info={"mediatype": "video", "title": name}, playable=True)
        if page * limit < total:
            self.item("[B]Další strana »[/B]", dict(self.params, page=page + 1), icon="DefaultFolder.png")
        self.end("videos")

    # ------------------------------------------------------------------ playback
    def do_play(self):
        p = self.params
        titles = unique([p.get("title", ""), p.get("otitle", "")])
        preferred = self.setting_choice("pref_lang", PREFERRED_AUDIO)
        with busy():
            if p["media"] == "movie":
                year = int(p["year"]) if p.get("year", "").isdigit() else None
                queries = []
                for t in titles:
                    norm = streams.normalize(t)
                    if year:
                        queries.append("%s %d" % (norm, year))
                    queries.append(norm)
                found = streams.rank_movie(self.search_all(queries), titles, year, preferred)
            else:
                season, episode = int(p["season"]), int(p["episode"])
                episode_titles = streams.distinctive_episode_titles([p.get("ename", ""), p.get("ename_en", "")])
                queries = ["%s s%02de%02d" % (streams.normalize(t), season, episode) for t in titles]
                queries += [streams.normalize(t) for t in episode_titles]
                found = streams.rank_episode(self.search_all(queries), titles, season, episode, preferred, episode_titles)
            found = self.file_details(found, preferred)
        self.remember_availability(p, bool(found))
        what = p.get("title", "")
        if p["media"] == "episode":
            what = "%s %sx%02d" % (what, p["season"], int(p["episode"]))
        if not found:
            raise UserError("Není na Webshare", heading=what, error=False)

        shown = [s for s in found if s["format"] in self.shown_formats()]
        if not shown:
            formats = [FORMAT_NAMES[f] for f in streams.FORMAT_ORDER if any(s["format"] == f for s in found)]
            if len(formats) == 1:
                message = "Je k dispozici jen ve formátu %s, který máš skrytý." % formats[0]
            else:
                message = "Je k dispozici jen ve formátech %s, které máš skryté." % ", ".join(formats)
            message += "\nZobrazit je můžeš v nastavení doplňku: Přehrávání → Zobrazované formáty."
            if not xbmcgui.Dialog().yesno(what, message, nolabel="Zavřít", yeslabel="Přesto zobrazit"):
                self.fail()
                return
            shown = found

        stream = self.choose_stream(shown)
        if stream is None:
            self.fail()
            return
        self.resolve(stream["ident"], p)

    # ------------------------------------------------------------------ TV programme
    def tv_schedule(self):
        """Films and series per TV day; parsed once per downloaded feed."""
        with busy():
            try:
                path = epg.download(os.path.join(self.storage.folder, "epg_cz.xml.gz"))
                key = "epg-schedule:%d" % os.path.getmtime(path)
                days = self.storage.cache_get(key, DAY)
                if days is None:
                    days = epg.schedule(path)
                    self.storage.cache_set(key, days)
            except Exception as exc:
                log("TV programme failed: %s" % exc, xbmc.LOGWARNING)
                raise UserError("Televizní program se teď nepodařilo stáhnout, zkus to později.")
        today = epg.tv_day(datetime.now().astimezone())
        return [d for d in days if d["date"] >= today], today

    def tv_find_day(self):
        days, _ = self.tv_schedule()
        day = next((d for d in days if d["date"] == self.params["date"]), None)
        if day is None:
            raise UserError("Program na tento den už není k dispozici.")
        return day

    def do_tv(self):
        days, today = self.tv_schedule()
        for day in days:
            label = day_label(day["date"], today)
            plot = "%d filmů, %d dílů seriálů" % (len(day["films"]), len(day["series"]))
            self.item(label, {"action": "tv_day", "date": day["date"]}, info={"mediatype": "video", "title": label, "plot": plot},
                      icon="DefaultYear.png")
        if not days:
            notify("Televizní program teď není k dispozici, zkus to později.")
        self.end(cache=False)

    def do_tv_day(self):
        day = self.tv_find_day()
        for kind, label, icon in (("films", "Filmy", "DefaultMovies.png"), ("series", "Seriály", "DefaultTVShows.png")):
            if day[kind]:
                self.item("%s  [COLOR grey](%d)[/COLOR]" % (label, len(day[kind])),
                          {"action": "tv_list", "date": day["date"], "kind": kind}, icon=icon)
        self.end(cache=False)

    def do_tv_list(self):
        kind = self.params["kind"]
        now = time.time()
        for f in self.tv_find_day()[kind]:
            start, stop = time.strftime("%H:%M", time.localtime(f["start"])), time.strftime("%H:%M", time.localtime(f["stop"]))
            when = "[COLOR FFFF9800]běží[/COLOR]" if f["start"] <= now < f["stop"] else "[B]%s[/B]" % start
            plot = "[COLOR grey]%s, %s–%s[/COLOR]" % (f["channel"], start, stop)
            if f["countries"]:
                plot += "\n[COLOR grey]Země:[/COLOR] %s" % ", ".join(f["countries"])
            if kind == "films":
                title = "%s (%s)" % (f["title"], f["year"]) if f["year"] else f["title"]
                params, playable = {"action": "tv_play", "title": f["title"], "year": f["year"]}, True
                info = {"mediatype": "movie", "title": f["title"], "year": f["year"]}
                query = title
            else:
                number = " [COLOR grey]%dx%02d[/COLOR]" % (f["season"], f["episode"]) if f["season"] else ""
                title = f["title"] + number
                if f["season"]:
                    params = {"action": "tv_play_episode", "title": f["title"], "season": f["season"],
                              "episode": f["episode"], "ename": f["subtitle"]}
                else:
                    params = {"action": "tv_show", "title": f["title"]}
                playable = bool(f["season"])
                info = {"mediatype": "episode", "title": f["subtitle"] or f["title"], "tvshowtitle": f["title"],
                        "season": f["season"], "episode": f["episode"]}
                query = "%s s%02de%02d" % (f["title"], f["season"], f["episode"]) if f["season"] else f["title"]
                if f["subtitle"]:
                    plot += "\n[COLOR grey]Díl:[/COLOR] %s" % f["subtitle"]
            info.update(genre=f["genres"], plot=plot + ("\n\n" + f["plot"] if f["plot"] else ""))
            context = [("Hledat přímo na Webshare", "Container.Update(%s)" % self.url(action="search", media="ws", query=query))]
            if playable:
                context.insert(0, ("Vybrat zdroj ručně", "PlayMedia(%s)" % self.url(**dict(params, select=1))))
            self.item("%s  %s  [COLOR grey]· %s[/COLOR]" % (when, title, f["channel"]), params,
                      art={"poster": f["icon"], "thumb": f["icon"]}, info=info, playable=playable, context=context)
        self.end("movies" if kind == "films" else "episodes", cache=False)

    def do_tv_play(self):
        """Plays a film from the TV programme: finds it on TMDB for the original title, then like any film."""
        title, year = self.params["title"], self.params.get("year", "")
        found = []
        for query in ({"query": title, "year": year}, {"query": title}):
            if not found and (query.get("year") or len(query) == 1):
                try:
                    found = self.tmdb.get("search/movie", ttl=7 * DAY, **query).get("results", [])
                except TmdbError:
                    found = []
        same = [r for r in found if streams.normalize(r.get("title", "")) == streams.normalize(title)]
        match = (same or found or [None])[0]
        if match:
            p = {"action": "play", "media": "movie", "id": match["id"], "title": match.get("title") or title,
                 "otitle": match.get("original_title") or "", "year": (match.get("release_date") or year)[:4],
                 "poster": match.get("poster_path") or "", "fanart": match.get("backdrop_path") or ""}
        else:
            p = {"action": "play", "media": "movie", "id": "tv-" + streams.normalize(title).replace(" ", "-"),
                 "title": title, "otitle": "", "year": year}
        if self.params.get("select"):
            p["select"] = "1"
        self.params = p
        self.do_play()

    def tv_find_show(self, title):
        try:
            found = self.tmdb.get("search/tv", ttl=7 * DAY, query=title).get("results", [])
        except TmdbError:
            found = []
        key = streams.normalize(title)
        same = [r for r in found if key in (streams.normalize(r.get("name", "")), streams.normalize(r.get("original_name", "")))]
        return (same or found or [None])[0]

    def do_tv_play_episode(self):
        p = self.params
        show = self.tv_find_show(p["title"]) or {}
        params = {"action": "play", "media": "episode", "id": show.get("id") or "tv-" + streams.normalize(p["title"]).replace(" ", "-"),
                  "title": show.get("name") or p["title"], "otitle": show.get("original_name", ""),
                  "season": p["season"], "episode": p["episode"], "ename": p.get("ename", ""),
                  "poster": show.get("poster_path") or "", "fanart": show.get("backdrop_path") or ""}
        if p.get("select"):
            params["select"] = "1"
        self.params = params
        self.do_play()

    def do_tv_show(self):
        """A series from the programme without an episode number: its seasons."""
        show = self.tv_find_show(self.params["title"])
        if not show:
            raise UserError("V databázi seriálů není", heading=self.params["title"], error=False)
        self.params = {"id": show["id"], "title": show.get("name") or self.params["title"],
                       "otitle": show.get("original_name", ""), "fanart": show.get("backdrop_path") or ""}
        self.do_seasons()

    def do_play_file(self):
        self.resolve(self.params["ident"], self.params)

    def search_all(self, queries):
        limit = self.setting_choice("ws_limit", WS_LIMITS)
        ws = Webshare()  # search works without login

        def search(query):
            try:
                return ws.search(query, limit=limit)[0]
            except WebshareError as exc:
                log("search '%s' failed: %s" % (query, exc), xbmc.LOGWARNING)
                return None

        with ThreadPoolExecutor(max_workers=3) as pool:
            results = list(pool.map(search, unique(queries)))
        if all(r is None for r in results):
            raise UserError("Webshare teď neodpovídá, zkus to za chvíli.")
        return [f for files in results if files for f in files]

    def shown_formats(self):
        """Formats ticked in Přehrávání → Zobrazované formáty (all of them by default)."""
        return {f for f in streams.FORMAT_ORDER if self.setting("show_" + f) != "false"}

    def file_details(self, found, preferred):
        """Asks Webshare for the real resolution and audio languages of the best candidates.

        File names often say nothing ('Film (2026).mkv'). Files Webshare no longer has are dropped.
        """
        ws = Webshare()
        found = found[:MAX_STREAMS]
        unclear = [s for s in found if not s["quality"] or not (s["lang"]["cz"] or s["lang"]["sk"] or s["lang"]["en"])]
        targets = list({s["ident"]: s for s in found[:15] + unclear}.values())[:MAX_DETAILS]

        def details(stream):
            key = "file_info:" + stream["ident"]
            info = self.storage.cache_get(key, 30 * DAY)
            if info is None:
                try:
                    info = ws.file_info(stream["ident"])
                except WebshareError as exc:
                    if "not found" not in str(exc).lower():
                        return stream["ident"], None
                    info = {"missing": True}
                self.storage.cache_set(key, info)
            return stream["ident"], info

        with ThreadPoolExecutor(max_workers=4) as pool:
            infos = dict(pool.map(details, targets))
        found = [s for s in found if not (infos.get(s["ident"]) or {}).get("missing")]
        return streams.refine(found, infos, preferred)

    def choose_stream(self, found):
        if self.setting("autoplay") == "true" and not self.params.get("select"):
            return streams.best(found)
        items = []
        for s in found:
            parts = ["Zvuk [B]%s[/B]" % (", ".join(s["audio"]) or "?"),
                     "Titulky %s" % (", ".join(s["subtitles"]) or "–")]
            if s["channels"] >= 6:
                parts.append("%d.1" % (s["channels"] - 1))
            parts.append(streams.format_size(s["size"]))
            if s["votes"] > 0:
                parts.append("+%d" % s["votes"])
            li = xbmcgui.ListItem("  ·  ".join(parts), s["name"], offscreen=True)
            badge = os.path.join(MEDIA_PATH, "quality_%s.png" % self.badge_name(s))
            li.setArt({"icon": badge, "thumb": badge})
            items.append(li)
        index = xbmcgui.Dialog().select("Vyber zdroj (%d)" % len(found), items, useDetails=True)
        return found[index] if index >= 0 else None

    @staticmethod
    def badge_name(s):
        if s["cam"]:
            return "cam"
        if s["quality"] == 4:
            return "4k_hdr" if s["hdr"] else "4k"
        return {3: "1080p", 2: "720p", 1: "sd"}.get(s["quality"], "unknown")

    def stream_link(self, ident):
        try:
            return self.webshare(login=True).file_link(ident)
        except WebshareError as exc:
            log("file_link failed (%s), logging in again" % exc, xbmc.LOGWARNING)
        try:
            return self.webshare(login=True, fresh=True).file_link(ident)
        except WebshareError as exc:
            raise UserError("Soubor nejde přehrát: %s" % exc)

    def resolve(self, ident, p):
        link = self.stream_link(ident)
        label = self.play_label(p)
        li = xbmcgui.ListItem(label, path=link, offscreen=True)
        li.setArt(self.art_for(p))
        set_video_info(li, self.play_info(p))
        if self.handle >= 0:
            xbmcplugin.setResolvedUrl(self.handle, True, li)
        else:
            xbmc.Player().play(link, li)

        params = {k: v for k, v in p.items() if k != "select"}
        key = self.url(**params)
        self.storage.push("history", {"key": key, "label": label, "params": params}, "key", 60)
        pick_audio_and_subtitles(self.setting_choice("pref_lang", PREFERRED_AUDIO))

    # ------------------------------------------------------------------ history, account, settings
    def do_history(self):
        entries = self.storage.load("history", [])
        if entries:
            self.item("[COLOR grey]Vymazat historii[/COLOR]", {"action": "history_clear"}, folder=False, icon="DefaultAddonNone.png")
        for entry in entries:
            p = entry["params"]
            remove = [("Odebrat z historie", "RunPlugin(%s)" % self.url(action="history_remove", key=entry["key"]))]
            if p.get("action") == "play_file":
                self.item(entry["label"], p, info=self.play_info(p), playable=True, context=remove)
            else:
                self.playable(entry["label"], p, self.play_info(p), remove)
        self.end("videos", cache=False)

    def do_history_remove(self):
        entries = self.storage.load("history", [])
        self.storage.save("history", [e for e in entries if e["key"] != self.params["key"]])
        xbmc.executebuiltin("Container.Refresh")

    def do_history_clear(self):
        if xbmcgui.Dialog().yesno(ADDON_NAME, "Opravdu vymazat celou historii přehrávání?"):
            self.storage.save("history", [])
            xbmc.executebuiltin("Container.Refresh")

    def do_account(self):
        data = self.webshare(login=True, fresh=True).user_data()
        lines = ["Uživatel: [B]%s[/B]" % data.get("username", ""), "E-mail: %s" % data.get("email", "")]
        if data.get("vip") == "1":
            lines.append("VIP: [COLOR lime]aktivní[/COLOR], zbývá %s dní" % data.get("vip_days", "?"))
        else:
            lines.append("VIP: [COLOR red]neaktivní[/COLOR] – bez VIP je přehrávání velmi pomalé")
        xbmcgui.Dialog().ok("Webshare – přihlášení funguje", "\n".join(lines))

    def do_settings(self):
        ADDON.openSettings()

    def do_logout(self):
        """Lets someone else sign in with their own Webshare account on this device."""
        if not xbmcgui.Dialog().yesno(ADDON_NAME, "Odhlásit účet Webshare a smazat uložené jméno a heslo?"):
            return
        state = self.storage.load("state", {})
        state.pop("token", None)
        state.pop("token_user", None)
        self.storage.save("state", state)
        ADDON.setSetting("ws_user", "")
        ADDON.setSetting("ws_pass", "")
        notify("Odhlášeno. V nastavení se teď může přihlásit kdokoli jiný.")

    def do_clear_cache(self):
        self.storage.cache_clear()
        notify("Mezipaměť vymazána")

    # ------------------------------------------------------------------ entry
    def run(self):
        handler = getattr(self, "do_" + self.action, None)
        if handler is None:
            raise UserError("Neznámá akce: %s" % self.action)
        handler()
        if self.refresh_imdb:
            # after the listing is on screen: the next listings will show IMDb ratings
            try:
                if self.imdb.refresh():
                    log("IMDb ratings updated")
            except Exception as exc:
                log("IMDb ratings update failed: %s" % exc, xbmc.LOGWARNING)


def run(argv):
    plugin = Plugin(argv)
    try:
        plugin.run()
    except (UserError, TmdbError, WebshareError) as exc:
        notify(str(exc), error=getattr(exc, "error", True), heading=getattr(exc, "heading", None))
        plugin.fail()
    except Exception:
        log(traceback.format_exc(), xbmc.LOGERROR)
        notify("Nastala chyba, podrobnosti jsou v kodi.log", error=True)
        plugin.fail()
