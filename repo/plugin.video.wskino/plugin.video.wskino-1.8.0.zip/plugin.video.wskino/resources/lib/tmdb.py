# -*- coding: utf-8 -*-
"""The Movie Database (TMDB) client used for the movie/series library."""
from urllib.parse import urlencode

import requests

API_URL = "https://api.themoviedb.org/3/"
IMAGE_URL = "https://image.tmdb.org/t/p/"


class TmdbError(Exception):
    pass


def image(path, size="w500"):
    return IMAGE_URL + size + path if path else ""


class Tmdb(object):
    def __init__(self, key, language="cs-CZ", storage=None, timeout=15):
        self.key = key.strip()
        self.language = language
        self.storage = storage
        self.timeout = timeout

    def get(self, path, ttl=6 * 3600, **params):
        params.setdefault("language", self.language)
        cache_key = path + "?" + urlencode(sorted(params.items()))
        if self.storage:
            cached = self.storage.cache_get(cache_key, ttl)
            if cached is not None:
                return cached

        headers = {"Accept": "application/json"}
        if self.key.startswith("eyJ"):  # v4 "API Read Access Token"
            headers["Authorization"] = "Bearer " + self.key
        else:
            params["api_key"] = self.key
        try:
            resp = requests.get(API_URL + path, params=params, headers=headers, timeout=self.timeout)
        except requests.RequestException as exc:
            raise TmdbError("TMDB je nedostupné: %s" % exc)
        if resp.status_code == 401:
            raise TmdbError("Neplatný TMDB API klíč – zkontroluj ho v nastavení doplňku.")
        if resp.status_code != 200:
            raise TmdbError("TMDB vrátilo chybu %d" % resp.status_code)

        data = resp.json()
        if self.storage:
            self.storage.cache_set(cache_key, data)
        return data
