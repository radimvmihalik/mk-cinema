# -*- coding: utf-8 -*-
"""Films and series on Czech TV, from the free community XMLTV feed of epgshare01.online.

The feed (~6 MB) is downloaded at most every 12 hours; it usually reaches only today and
part of tomorrow, other free feeds don't have film/series details. A programme counts as a
film when it has a production year, no episode number, runs at least an hour and isn't a
documentary; as a series episode when it has an episode number. Some channels (ČT1, ČT2, the main Nova and Prima) often
come without these details in the feed, so their films can be missing.
"""
import gzip
import os
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

import requests

EPG_URL = "https://epgshare01.online/epgshare01/epg_ripper_CZ1.xml.gz"
DOWNLOAD_EVERY = 12 * 3600
MIN_MINUTES = 60

# Display names in the feed of channels a Czech viewer gets (terrestrial, cable, satellite, IPTV)
CHANNELS = {
    "ČT1", "ČT2", "ČT :D", "ČT art", "Nova", "Nova Cinema", "Nova Action", "Nova Fun", "Nova Krimi", "Nova Lady",
    "Nova Gold", "Prima", "Prima Cool", "Prima Krimi", "Prima LOVE", "Prima MAX", "Prima Star", "Prima Show",
    "Prima ZOOM", "Barrandov", "Barrandov Kino", "Barrandov Krimi", "JOJ Family", "JOJ Cinema", "Markíza",
    "Markíza KLASIK", "CS Film", "CS Horror", "CS Mystery", "CS History", "Film+", "Film Europe", "Film Europe +",
    "Filmbox+ hits", "Filmbox+ one", "Filmbox+ comedy", "Filmbox+ emotion", "Filmbox+ festival",
    "Filmbox+ love&crime", "HBO", "HBO2", "HBO3", "Cinemax", "Cinemax 2", "AMC", "AXN", "AXN Black", "AXN White",
    "Canal+ Action", "Epic Drama", "Viasat Kino", "Warner TV", "Spektrum",
}


def _time(value):
    """'20261022200000 +0200' -> aware datetime.

    Parsed by hand: datetime.strptime fails inside Kodi's embedded Python
    ("'NoneType' object is not callable") from the second call on.
    """
    stamp, _, offset = value.strip().partition(" ")
    tz = timezone.utc
    if len(offset) == 5:
        sign = -1 if offset[0] == "-" else 1
        tz = timezone(sign * timedelta(hours=int(offset[1:3]), minutes=int(offset[3:5])))
    return datetime(int(stamp[0:4]), int(stamp[4:6]), int(stamp[6:8]), int(stamp[8:10]), int(stamp[10:12]),
                    int(stamp[12:14] or 0), tzinfo=tz)


def download(path, timeout=60):
    """Fresh copy of the feed at path (kept for DOWNLOAD_EVERY)."""
    if os.path.isfile(path) and time.time() - os.path.getmtime(path) < DOWNLOAD_EVERY:
        return path
    tmp = path + ".download"
    with requests.get(EPG_URL, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with open(tmp, "wb") as fh:
            for chunk in resp.iter_content(1 << 16):
                fh.write(chunk)
    os.replace(tmp, path)
    return path


DAY_STARTS_AT = 5  # programmes after midnight belong to the previous TV day, like in a printed TV guide
MIN_EPISODE_MINUTES = 15
_EPISODE = re.compile(r"S\s*(\d+)\s*E\s*(\d+)", re.I)


def tv_day(moment):
    """'2026-10-23' for anything from 05:00 that day until 04:59 the next morning (local time)."""
    return (moment.astimezone() - timedelta(hours=DAY_STARTS_AT)).date().isoformat()


def _episode(el):
    """(season, episode) from <episode-num>, either 'S1 E5' (onscreen) or '0.4.' (xmltv_ns, zero-based)."""
    for num in el.findall("episode-num"):
        text = (num.text or "").strip()
        match = _EPISODE.search(text)
        if match:
            return int(match.group(1)), int(match.group(2))
        if num.get("system") == "xmltv_ns":
            parts = text.split(".")
            try:
                return int(parts[0].split("/")[0]) + 1, int(parts[1].split("/")[0]) + 1
            except (IndexError, ValueError):
                pass
    return None, None


def schedule(path, today=None):
    """Films and series on Czech channels, per TV day from today on, as far ahead as the feed goes.

    Returns [{"date": "2026-10-23", "films": [...], "series": [...]}, ...], each list sorted by start.
    """
    today = today or tv_day(datetime.now().astimezone())
    days, names, seen = {}, {}, set()
    with gzip.open(path) as fh:
        for _, el in ET.iterparse(fh, events=("end",)):
            if el.tag == "channel":
                names[el.get("id")] = el.findtext("display-name")
                el.clear()
                continue
            if el.tag != "programme":
                continue
            channel = names.get(el.get("channel"))
            if channel not in CHANNELS:
                el.clear()
                continue
            start, stop = _time(el.get("start")), _time(el.get("stop"))
            day, minutes = tv_day(start), (stop - start).total_seconds() / 60
            genres = [c.text for c in el.findall("category") if c.text]
            is_series = el.find("episode-num") is not None
            if day < today or (not is_series and not el.findtext("date")) or "Dokument" in genres \
                    or minutes < (MIN_EPISODE_MINUTES if is_series else MIN_MINUTES):
                el.clear()
                continue
            season, episode = _episode(el) if is_series else (None, None)
            title = el.findtext("title") or ""
            key = (day, title, season, episode, start.timestamp()) if is_series else (day, title, start.timestamp())
            if key in seen:  # the same airing on a sister channel (e.g. Nova and Nova International)
                el.clear()
                continue
            seen.add(key)
            icon = el.find("icon")
            days.setdefault(day, {"films": [], "series": []})["series" if is_series else "films"].append({
                "channel": channel,
                "start": start.timestamp(),
                "stop": stop.timestamp(),
                "title": title,
                "subtitle": el.findtext("sub-title") or "",
                "year": (el.findtext("date") or "")[:4],
                "season": season,
                "episode": episode,
                "plot": el.findtext("desc") or "",
                "icon": icon.get("src", "") if icon is not None else "",
                "genres": genres,
                "countries": [c.text for c in el.findall("country") if c.text],
            })
            el.clear()
    out = []
    for day in sorted(days):
        for kind in ("films", "series"):
            days[day][kind].sort(key=lambda f: (f["start"], f["channel"]))
        out.append(dict(days[day], date=day))
    return out
