# -*- coding: utf-8 -*-
"""Minimal client for the official Webshare.cz API (https://webshare.cz/apidoc/)."""
import hashlib
import xml.etree.ElementTree as ET

import requests

from .md5crypt import md5crypt

API_URL = "https://webshare.cz/api/"
HEADERS = {
    "User-Agent": "Kodi MK Cinema",
    "Referer": "https://webshare.cz/",
    "Accept": "text/xml; charset=UTF-8",
}


class WebshareError(Exception):
    def __init__(self, message, code=None):
        super(WebshareError, self).__init__(message)
        self.code = code


def _to_dict(element):
    return {child.tag: (child.text or "") for child in element}


def _to_int(text):
    try:
        return int(float(text or 0))
    except ValueError:
        return 0


class Webshare(object):
    def __init__(self, token="", device_uuid="", timeout=20):
        self.token = token
        self.device_uuid = device_uuid
        self.timeout = timeout

    def _call(self, method, data):
        try:
            resp = requests.post(API_URL + method + "/", data=data, headers=HEADERS, timeout=self.timeout)
            if resp.status_code in (403, 429):
                raise WebshareError("Webshare dočasně omezil počet dotazů, zkus to za chvíli.", "RATE_LIMIT")
            resp.raise_for_status()
        except requests.RequestException as exc:
            raise WebshareError("Webshare je nedostupný: %s" % exc)
        root = ET.fromstring(resp.content)
        if root.findtext("status") != "OK":
            raise WebshareError(root.findtext("message") or "Neznámá chyba Webshare", root.findtext("code"))
        return root

    def login(self, username, password):
        salt = self._call("salt", {"username_or_email": username}).findtext("salt") or ""
        hashed = hashlib.sha1(md5crypt(password, salt).encode("utf-8")).hexdigest()
        digest = hashlib.md5((username + ":Webshare:" + hashed).encode("utf-8")).hexdigest()
        root = self._call("login", {
            "username_or_email": username,
            "password": hashed,
            "digest": digest,
            "keep_logged_in": 1,
        })
        self.token = root.findtext("token") or ""
        return self.token

    def user_data(self):
        return _to_dict(self._call("user_data", {"wst": self.token}))

    def search(self, what, limit=100, offset=0, sort="", category="video"):
        root = self._call("search", {
            "what": what,
            "category": category,
            "sort": sort,
            "limit": limit,
            "offset": offset,
            "wst": self.token,
        })
        files = [_to_dict(f) for f in root.findall("file")]
        return files, int(root.findtext("total") or 0)

    def file_info(self, ident):
        """Real resolution and audio tracks of a file (works without login)."""
        root = self._call("file_info", {"ident": ident, "wst": self.token})
        audio = [{"language": (a.findtext("language") or "").upper(), "channels": _to_int(a.findtext("channels"))}
                 for a in root.findall("audio/stream")]
        return {"width": _to_int(root.findtext("width")), "height": _to_int(root.findtext("height")),
                "length": _to_int(root.findtext("length")), "audio": audio}

    def file_link(self, ident):
        root = self._call("file_link", {
            "ident": ident,
            "wst": self.token,
            "download_type": "video_stream",
            "device_uuid": self.device_uuid,
        })
        return root.findtext("link") or ""
