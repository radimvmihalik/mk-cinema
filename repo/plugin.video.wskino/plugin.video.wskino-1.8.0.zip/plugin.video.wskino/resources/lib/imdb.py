# -*- coding: utf-8 -*-
"""IMDb ratings from IMDb's official dataset (https://datasets.imdbws.com/, free for personal use).

The ~9 MB file is downloaded once a week into a small SQLite table, so a lookup
needs no network request.
"""
import gzip
import os
import sqlite3
import time

import requests

DATASET_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
REFRESH_AFTER = 7 * 24 * 3600
MIN_VOTES = 100  # titles with fewer votes say little and only make the table bigger


def _number(imdb_id):
    try:
        return int(imdb_id[2:]) if imdb_id and imdb_id.startswith("tt") else None
    except ValueError:
        return None


class ImdbRatings(object):
    def __init__(self, folder):
        self.path = os.path.join(folder, "imdb_ratings.sqlite")
        self.lock = self.path + ".lock"

    def is_fresh(self):
        return os.path.isfile(self.path) and time.time() - os.path.getmtime(self.path) < REFRESH_AFTER

    def get(self, imdb_ids):
        """{imdb_id: (rating, votes)} for the ids that have a rating."""
        numbers = {_number(i): i for i in imdb_ids if _number(i)}
        if not numbers or not os.path.isfile(self.path):
            return {}
        con = sqlite3.connect(self.path)
        try:
            rows = con.execute("SELECT id, rating, votes FROM ratings WHERE id IN (%s)" % ",".join("?" * len(numbers)),
                               list(numbers)).fetchall()
        except sqlite3.Error:
            return {}
        finally:
            con.close()
        return {numbers[n]: (rating, votes) for n, rating, votes in rows}

    def refresh(self, timeout=120):
        """Downloads the dataset and rebuilds the table. Returns False when another refresh is running."""
        if os.path.isfile(self.lock) and time.time() - os.path.getmtime(self.lock) < 1800:
            return False
        open(self.lock, "w").close()
        download, table = self.path + ".download", self.path + ".new"
        try:
            with requests.get(DATASET_URL, stream=True, timeout=timeout) as resp:
                resp.raise_for_status()
                with open(download, "wb") as fh:
                    for chunk in resp.iter_content(1 << 16):
                        fh.write(chunk)
            if os.path.exists(table):
                os.remove(table)
            con = sqlite3.connect(table)
            con.execute("CREATE TABLE ratings (id INTEGER PRIMARY KEY, rating REAL, votes INTEGER)")
            with gzip.open(download, "rt", encoding="utf-8") as lines:
                next(lines)  # header: tconst, averageRating, numVotes
                rows = ((int(t[2:]), float(r), int(v)) for t, r, v in (line.rstrip("\n").split("\t") for line in lines)
                        if int(v) >= MIN_VOTES)
                con.executemany("INSERT INTO ratings VALUES (?, ?, ?)", rows)
            con.commit()
            con.close()
            os.replace(table, self.path)
            return True
        finally:
            for leftover in (download, table, self.lock):
                if os.path.exists(leftover):
                    os.remove(leftover)
