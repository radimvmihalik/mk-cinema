# -*- coding: utf-8 -*-
import sys

from resources.lib.plugin import run

if __name__ == "__main__":
    run(sys.argv)
