# -*- coding: utf-8 -*-
"""Picks the Webshare files that belong to a movie/episode and ranks them.

Pure Python (no Kodi imports) so it can be tested outside Kodi.
"""
import re
import unicodedata

STOPWORDS = {
    "the", "a", "an", "of", "and", "in", "on", "to", "at", "for",
    "la", "le", "les", "de", "der", "die", "das", "el",
    "i", "v", "ve", "na", "se", "s", "z", "ze", "o", "do", "k",
}
ROMAN = {"ii": "2", "iii": "3", "iv": "4", "vi": "6", "vii": "7", "viii": "8", "ix": "9"}
SEQUEL_NUMBERS = {"2", "3", "4", "5", "6", "7", "8", "9"}
JUNK = {"sample", "trailer", "teaser", "ukazka"}
# Recorded in a cinema: always listed last
CAM = {"cam", "camrip", "hdcam", "ts", "hdts", "telesync", "tc", "telecine", "kinorip"}
HDR = {"hdr", "hdr10", "dv", "dovi", "dolbyvision"}
# Audio track languages reported by Webshare file_info
AUDIO_LANGUAGES = {"CZE": "cz", "CES": "cz", "CZ": "cz", "SLO": "sk", "SLK": "sk", "SK": "sk", "ENG": "en", "EN": "en"}

CZ = {"cz", "cze", "ces", "czech", "cesky", "ceske", "cestina", "czdab", "czdabing", "czaudio", "dabcz"}
SK = {"sk", "svk", "slovak", "slovensky", "slovenske", "skdab", "skdabing", "skaudio", "dabsk"}
EN = {"en", "eng", "english"}
DUB = {"dab", "dabing", "dabbing", "dabovane", "dabovany", "dub", "dubbed",
       "czdab", "czdabing", "skdab", "skdabing", "dabcz", "dabsk"}
SUB = {"tit", "titl", "titulky", "titulkami", "sub", "subs", "subtitles"}
CZ_SUB = {"cztit", "cztitulky", "czsub", "czsubs", "titcz"}
SK_SUB = {"sktit", "sktitulky", "sksub", "sksubs", "titsk"}
# Words that may precede the title in a file name, e.g. "[CZ] 1080p Interstellar"
PREFIX_TAGS = CZ | SK | EN | DUB | SUB | CZ_SUB | SK_SUB | {"www", "film", "novinka", "new", "hd", "fhd", "uhd", "4k", "720p", "1080p", "2160p"}

QUALITY_LABELS = {4: "4K", 3: "1080p", 2: "720p", 1: "SD", 0: "?"}
FORMATS = {4: "4k", 3: "1080p", 2: "720p", 1: "sd", 0: "unknown"}
FORMAT_ORDER = ["4k", "1080p", "720p", "sd", "unknown", "cam"]
_QUALITY_PATTERNS = [
    (4, re.compile(r"\b(2160p?|4k|uhd)\b")),
    (3, re.compile(r"\b(1080p?|1080i|fhd|full ?hd)\b")),
    (2, re.compile(r"\b(720p?|hd)\b")),
    (1, re.compile(r"\b(480p?|576p?|sd|dvdrip|dvd|xvid|divx|vhsrip|tvrip)\b")),
]
_EPISODE_RE = re.compile(r"\bs\d{1,2} ?e\d{1,3}\b|\b\d{1,2}x\d{1,3}\b")
_YEAR_RE = re.compile(r"^(19|20)\d\d$")

MAX_TITLE_START = 3
MIN_MOVIE_SIZE = 200 * 1024 * 1024
MIN_EPISODE_SIZE = 30 * 1024 * 1024


def normalize(text):
    text = unicodedata.normalize("NFKD", text or "")
    text = "".join(c for c in text if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def is_latin(text):
    """False for titles in Chinese, Japanese, Korean, Cyrillic... which Kodi's default font can't show."""
    return all(not ch.isalpha() or "LATIN" in unicodedata.name(ch, "") for ch in text or "")


def tokens(text):
    return [ROMAN.get(w, w) for w in normalize(text).split()]


def core_tokens(text):
    toks = tokens(text)
    core = [w for w in toks if w not in STOPWORDS]
    return core or toks


def _find_sequence(haystack, needle):
    n = len(needle)
    for i in range(len(haystack) - n + 1):
        if haystack[i:i + n] == needle:
            return i
    return -1


def _main_titles(title):
    """'Star Wars: Epizoda IV – Nová naděje' -> ['Star Wars: Epizoda IV', 'Star Wars']."""
    parts = []
    for sep in (r" [-–] ", r":"):
        part = re.split(sep, title, maxsplit=1)[0].strip()
        if part and part != title.strip() and part not in parts:
            parts.append(part)
    return parts


def detect_quality(norm_name):
    for value, pattern in _QUALITY_PATTERNS:
        if pattern.search(norm_name):
            return value
    return 0


def detect_languages(toks):
    s = set(toks)
    has_cz, has_sk, has_dub, has_sub = bool(s & CZ), bool(s & SK), bool(s & DUB), bool(s & SUB)
    cz_sub = bool(s & CZ_SUB) or (has_cz and has_sub and not has_dub)
    sk_sub = bool(s & SK_SUB) or (has_sk and has_sub and not has_dub)
    cz_dub = (has_cz and not cz_sub) or (has_dub and not has_cz and not has_sk)
    sk_dub = has_sk and not sk_sub
    return {"cz": cz_dub, "sk": sk_dub, "en": bool(s & EN), "cz_sub": cz_sub, "sk_sub": sk_sub}


def audio_tags(lang):
    return [code.upper() for code in ("cz", "sk", "en") if lang[code]]


def subtitle_tags(lang):
    return [code.upper() for code in ("cz", "sk") if lang[code + "_sub"]]


def language_score(lang, preferred):
    if preferred == "CZ":
        return 4 if lang["cz"] else 3 if lang["sk"] else 2 if lang["cz_sub"] else 1 if lang["sk_sub"] else 0
    if preferred == "SK":
        return 4 if lang["sk"] else 3 if lang["cz"] else 2 if lang["sk_sub"] else 1 if lang["cz_sub"] else 0
    if preferred == "EN":
        dubbed = lang["cz"] or lang["sk"]
        return 3 if lang["en"] else 0 if dubbed else 2
    return 0


def _starts_cleanly(name_core, start, allowed):
    """Only numbers, tags or words of the other titles may come before the title.

    Otherwise 'The Watcher S01E01 Vitejte pratele' would match the series 'Pratele'
    and 'Still Hope 2026' the film 'Hope'.
    """
    prefix = name_core[:start]
    return len(prefix) <= MAX_TITLE_START and all(w.isdigit() or w in allowed or w in PREFIX_TAGS for w in prefix)


def _title_score(name_core, title, allowed=frozenset()):
    """3 = title found as a phrase, 2 = all title words present, 0 = no match."""
    tt = core_tokens(title)
    if not tt or not set(tt) <= set(name_core):
        return 0, False
    idx = _find_sequence(name_core, tt)
    if idx < 0:
        return (2 if _starts_cleanly(name_core, name_core.index(tt[0]), allowed) else 0), False
    if not _starts_cleanly(name_core, idx, allowed):
        return 0, False
    after = name_core[idx + len(tt)] if idx + len(tt) < len(name_core) else ""
    looks_like_sequel = after in SEQUEL_NUMBERS and tt[-1] not in SEQUEL_NUMBERS
    return 3, looks_like_sequel


def _build(item, norm_name, toks, preferred):
    stream = {
        "ident": item.get("ident", ""),
        "name": item.get("name", ""),
        "size": int(item.get("size") or 0),
        "img": item.get("img", ""),
        "votes": int(item.get("positive_votes") or 0) - int(item.get("negative_votes") or 0),
        "quality": detect_quality(norm_name),
        "lang": detect_languages(toks),
        "cam": bool(set(toks) & CAM),
        "hdr": bool(set(toks) & HDR) or "dolby vision" in norm_name,
        "channels": 0,
    }
    finalize(stream, preferred)
    return stream


def finalize(stream, preferred):
    """(Re)computes the labels and ranking fields from quality and languages."""
    quality = stream["quality"]
    stream.update(
        quality_label="CAM" if stream["cam"] else QUALITY_LABELS[quality],
        format="cam" if stream["cam"] else FORMATS[quality],
        audio=audio_tags(stream["lang"]),
        subtitles=subtitle_tags(stream["lang"]),
        lang_score=language_score(stream["lang"], preferred),
    )


def quality_from_resolution(width, height):
    if width >= 3000 or height >= 1700:
        return 4
    if width >= 1700 or height >= 1000:
        return 3
    if width >= 1200 or height >= 700:
        return 2
    return 1 if width else 0


def refine(found, infos, preferred="CZ"):
    """Replaces guesses from file names with Webshare's real video/audio info; returns display order."""
    for stream in found:
        info = infos.get(stream["ident"])
        if info:
            quality = quality_from_resolution(info.get("width", 0), info.get("height", 0))
            if quality:
                stream["quality"] = quality
            audio = info.get("audio", [])
            codes = {AUDIO_LANGUAGES.get(a.get("language", "")) for a in audio} - {None}
            if codes:
                for code in ("cz", "sk", "en"):
                    stream["lang"][code] = code in codes
            stream["channels"] = max([a.get("channels", 0) for a in audio] or [0])
            finalize(stream, preferred)
    return display_order(found)


def display_order(found):
    """What the source list shows: 4K first, down to SD, '?' and CAM; biggest files first within a format."""
    return sorted(found, key=lambda s: (FORMAT_ORDER.index(s["format"]), -s["size"]))


def _relevance(s):
    quality = 1.5 if s["quality"] == 0 else s["quality"]
    return (not s["cam"], s["lang_score"], quality, s["match"], s["votes"], s["size"])


def best(found):
    """The source autoplay picks: preferred language first, then quality."""
    return max(found, key=_relevance)


def _usable(item, min_size):
    if item.get("password") == "1" or int(item.get("queued") or 0):
        return False
    return int(item.get("size") or 0) >= min_size


def _dedupe_and_sort(found):
    """Unique files, most relevant first (the order in which file details are fetched)."""
    seen, unique = set(), []
    for s in found:
        key = (normalize(s["name"]), s["size"])
        if s["ident"] and key not in seen:
            seen.add(key)
            unique.append(s)
    return sorted(unique, key=_relevance, reverse=True)


def rank_movie(files, titles, year=None, preferred="CZ"):
    titles = [t for t in titles if t]
    title_words = set()
    for t in titles:
        title_words.update(core_tokens(t))
    found = []
    for item in files:
        if not _usable(item, MIN_MOVIE_SIZE):
            continue
        norm_name = normalize(item.get("name", ""))
        toks = tokens(item.get("name", ""))
        if _EPISODE_RE.search(norm_name) or set(toks) & JUNK:
            continue
        name_core = [w for w in toks if w not in STOPWORDS]
        years = [int(w) for w in name_core if _YEAR_RE.match(w) and w not in title_words]
        if year and years:
            year_state = 1 if any(abs(y - year) <= 1 for y in years) else -1
        else:
            year_state = 0
        if year_state < 0:
            continue

        best = 0
        for t in titles:
            score, sequel = _title_score(name_core, t, title_words)
            if sequel and year_state < 1:
                score = 0
            best = max(best, score)
        if not best and year_state == 1:
            # 'Mission: Impossible 7 (2023)' still matches 'Mission: Impossible - Dead Reckoning' by year
            for t in titles:
                if any(_find_sequence(name_core, core_tokens(main)) == 0 for main in _main_titles(t)):
                    best = 1
        if not best:
            continue

        stream = _build(item, norm_name, toks, preferred)
        stream["match"] = best + year_state
        found.append(stream)
    return _dedupe_and_sort(found)


def distinctive_episode_titles(names):
    """Episode titles specific enough to identify a file even without the show name.

    'Speciální čarodějnický díl XXVII' is, 'Halloween' or TMDB's placeholder 'Epizoda 5' is not.
    """
    out = []
    for name in names:
        core = core_tokens(name or "")
        if len(core) >= 3 and not re.match(r"^(epizoda|episode|dil) \d+$", " ".join(core)) and name not in out:
            out.append(name)
    return out


def _numbered_title(episode_title):
    """'Speciální čarodějnický díl XXVII' tells the episodes apart, 'Speciální čarodějnický díl' does not."""
    return any(w.isdigit() or re.match(r"^[ivxlc]+$", w) for w in core_tokens(episode_title))


def _episode_title_found(name_core, episode_title):
    tt = core_tokens(episode_title)
    idx = _find_sequence(name_core, tt)
    if idx < 0:
        return False
    after = name_core[idx + len(tt)] if idx + len(tt) < len(name_core) else ""
    # 'Treehouse of Horror' must not match 'Treehouse of Horror II' (roman numerals become digits)
    return not (after.isdigit() and len(after) <= 2)


def rank_episode(files, titles, season, episode, preferred="CZ", episode_titles=()):
    """A file matches when it has the episode number and the show or episode title,
    or both titles without a number. Many uploads are named only '35x05 <episode title>'."""
    titles = [t for t in titles if t]
    episode_titles = distinctive_episode_titles(episode_titles)
    title_words = set()
    for t in titles:
        title_words.update(core_tokens(t))
    pattern = re.compile(r"\bs0*%d ?e0*%d\b|\b0*%dx0*%d\b|^0*%d 0*%d\b" % ((season, episode) * 3))
    found = []
    for item in files:
        if not _usable(item, MIN_EPISODE_SIZE):
            continue
        norm_name = normalize(item.get("name", ""))
        toks = tokens(item.get("name", ""))
        if set(toks) & JUNK:
            continue
        name_core = [w for w in toks if w not in STOPWORDS]
        numbered = bool(pattern.search(norm_name))
        show = max([_title_score(name_core, t, title_words)[0] for t in titles] or [0]) > 0
        named = [t for t in episode_titles if _episode_title_found(name_core, t)]
        if not ((numbered and (show or named)) or (show and any(_numbered_title(t) for t in named))):
            continue
        stream = _build(item, norm_name, toks, preferred)
        stream["match"] = 2 * numbered + show + bool(named)
        found.append(stream)
    return _dedupe_and_sort(found)


def format_size(size):
    if size >= 1024 ** 3:
        return "%.1f GB" % (size / 1024.0 ** 3)
    return "%d MB" % (size // 1024 ** 2)
