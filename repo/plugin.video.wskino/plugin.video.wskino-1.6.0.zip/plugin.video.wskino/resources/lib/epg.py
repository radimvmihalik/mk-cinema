# -*- coding: utf-8 -*-
"""Films on Czech TV today, from the free community XMLTV feed of epgshare01.online.

The feed (~6 MB, a few days ahead) is downloaded at most every 12 hours. A programme
counts as a film when it has a production year, no episode number, runs at least an
hour and isn't a documentary. Some channels (ČT1, ČT2, the main Nova and Prima) often
come without these details in the feed, so their films can be missing.
"""
import gzip
import os
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

import requests

EPG_URL = "https://epgshare01.online/epgshare01/epg_ripper_CZ1.xml.gz"
DOWNLOAD_EVERY = 12 * 3600
MIN_MINUTES = 60

# Display names in the feed of channels a Czech viewer gets (terrestrial, cable, satellite, IPTV)
CHANNELS = {
    "ČT1", "ČT2", "ČT :D", "ČT art", "Nova", "Nova Cinema", "Nova Action", "Nova Fun", "Nova Krimi", "Nova Lady",
    "Nova Gold", "Prima", "Prima Cool", "Prima Krimi", "Prima LOVE", "Prima MAX", "Prima Star", "Prima Show",
    "Prima ZOOM", "Barrandov", "Barrandov Kino", "Barrandov Krimi", "JOJ Family", "JOJ Cinema", "Markíza",
    "Markíza KLASIK", "CS Film", "CS Horror", "CS Mystery", "CS History", "Film+", "Film Europe", "Film Europe +",
    "Filmbox+ hits", "Filmbox+ one", "Filmbox+ comedy", "Filmbox+ emotion", "Filmbox+ festival",
    "Filmbox+ love&crime", "HBO", "HBO2", "HBO3", "Cinemax", "Cinemax 2", "AMC", "AXN", "AXN Black", "AXN White",
    "Canal+ Action", "Epic Drama", "Viasat Kino", "Warner TV", "Spektrum",
}


def _time(value):
    """'20261022200000 +0200' -> aware datetime.

    Parsed by hand: datetime.strptime fails inside Kodi's embedded Python
    ("'NoneType' object is not callable") from the second call on.
    """
    stamp, _, offset = value.strip().partition(" ")
    tz = timezone.utc
    if len(offset) == 5:
        sign = -1 if offset[0] == "-" else 1
        tz = timezone(sign * timedelta(hours=int(offset[1:3]), minutes=int(offset[3:5])))
    return datetime(int(stamp[0:4]), int(stamp[4:6]), int(stamp[6:8]), int(stamp[8:10]), int(stamp[10:12]),
                    int(stamp[12:14] or 0), tzinfo=tz)


def download(path, timeout=60):
    """Fresh copy of the feed at path (kept for DOWNLOAD_EVERY)."""
    if os.path.isfile(path) and time.time() - os.path.getmtime(path) < DOWNLOAD_EVERY:
        return path
    tmp = path + ".download"
    with requests.get(EPG_URL, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with open(tmp, "wb") as fh:
            for chunk in resp.iter_content(1 << 16):
                fh.write(chunk)
    os.replace(tmp, path)
    return path


def films(path, now=None, until_hour=6):
    """Films still running or starting before `until_hour` the next morning, sorted by start."""
    now = now or datetime.now().astimezone()
    end = (now + timedelta(days=1)).replace(hour=until_hour, minute=0, second=0, microsecond=0)
    names, found = {}, []
    with gzip.open(path) as fh:
        for _, el in ET.iterparse(fh, events=("end",)):
            if el.tag == "channel":
                names[el.get("id")] = el.findtext("display-name")
                el.clear()
            elif el.tag == "programme":
                channel = names.get(el.get("channel"))
                if channel in CHANNELS and el.findtext("date") and el.find("episode-num") is None:
                    start, stop = _time(el.get("start")), _time(el.get("stop"))
                    genres = [c.text for c in el.findall("category") if c.text]
                    if (stop > now and start < end and (stop - start).total_seconds() >= MIN_MINUTES * 60
                            and "Dokument" not in genres):
                        icon = el.find("icon")
                        found.append({
                            "channel": channel,
                            "start": start.timestamp(),
                            "stop": stop.timestamp(),
                            "title": el.findtext("title") or "",
                            "year": (el.findtext("date") or "")[:4],
                            "plot": el.findtext("desc") or "",
                            "icon": icon.get("src", "") if icon is not None else "",
                            "genres": genres,
                            "countries": [c.text for c in el.findall("country") if c.text],
                        })
                el.clear()
    found.sort(key=lambda f: (f["start"], f["channel"]))
    return found
